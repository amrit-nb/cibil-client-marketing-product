(function () {
  var planSwitch = document.querySelector('.plan-switch');
  if (planSwitch) {
    var expandComboPill = function () {
      planSwitch.classList.remove('plan-switch--s1', 'plan-switch--s2');
    };

    var PARAM = 'plan';
    var tabs = Array.prototype.map.call(planSwitch.querySelectorAll('.plan-switch__tab'), function (b) { return b.dataset.tab; });

    var switchTab = function (tab, updateUrl) {
      if (tabs.indexOf(tab) === -1) return;
      expandComboPill();
      if (updateUrl !== false) {
        try {
          var url = new URL(location.href);
          url.searchParams.set(PARAM, tab);
          history.replaceState(history.state, '', url);
        } catch (e) {}
      }
      planSwitch.querySelectorAll('.plan-switch__tab').forEach(function (btn) {
        var on = btn.dataset.tab === tab;
        btn.classList.toggle('is-active', on);
        btn.setAttribute('aria-selected', String(on));
        btn.tabIndex = on ? 0 : -1;
      });
      document.querySelectorAll('[data-tab-show]').forEach(function (el) {
        el.classList.toggle('hidden', el.dataset.tabShow !== tab);
      });
      document.querySelectorAll('.tab-panel').forEach(function (panel) {
        var active = panel.dataset.panel === tab;
        panel.classList.toggle('is-active', active);
        if (active) {
          panel.classList.remove('panel-anim');
          void panel.offsetWidth;
          panel.classList.add('panel-anim');
        }
      });
    };

    planSwitch.querySelectorAll('.plan-switch__tab').forEach(function (btn) {
      btn.addEventListener('click', function () { switchTab(btn.dataset.tab); });
    });
    planSwitch.addEventListener('keydown', function (e) {
      var i = tabs.indexOf(document.activeElement && document.activeElement.dataset.tab);
      if (i === -1) return;
      var next = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: tabs.length - 1 }[e.key];
      if (next === undefined) return;
      e.preventDefault();
      var tab = tabs[(next + tabs.length) % tabs.length];
      switchTab(tab);
      planSwitch.querySelector('[data-tab="' + tab + '"]').focus();
    });
    document.querySelectorAll('[data-open-tab]').forEach(function (link) {
      link.addEventListener('click', function () { switchTab(link.dataset.openTab); });
    });

    var initialTab = new URLSearchParams(location.search).get(PARAM);
    if (tabs.indexOf(initialTab) !== -1) {
      switchTab(initialTab, false);
      if (!location.hash) {
        requestAnimationFrame(function () { document.getElementById('plans').scrollIntoView(); });
      }
    }

    setTimeout(function () {
      if (planSwitch.classList.contains('plan-switch--s1')) {
        planSwitch.classList.remove('plan-switch--s1');
        planSwitch.classList.add('plan-switch--s2');
      }
    }, 1200);
    setTimeout(expandComboPill, 2800);
  }

  var why = document.querySelector('[data-why]');
  if (why) {
    var items = Array.prototype.slice.call(why.querySelectorAll('.why-item'));
    var panels = Array.prototype.slice.call(document.querySelectorAll('.why-panel'));
    var DELAY = 4000;
    var timer = null;
    var current = 0;
    var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    why.style.setProperty('--why-delay', DELAY + 'ms');

    var activate = function (index, autoplay) {
      items.forEach(function (item, i) {
        item.classList.toggle('is-active', i === index);
        item.classList.remove('is-running');
        item.querySelector('.why-item__btn').setAttribute('aria-expanded', String(i === index));
      });
      panels.forEach(function (panel, i) { panel.classList.toggle('is-active', i === index); });
      current = index;
      clearTimeout(timer);
      if (!autoplay || reduceMotion || paused) return;
      void items[index].offsetWidth;
      items[index].classList.add('is-running');
      timer = setTimeout(function () { activate((current + 1) % items.length, true); }, DELAY);
    };

    var mobile = window.matchMedia('(max-width: 767.98px)');

    items.forEach(function (item, i) {
      var slot = item.querySelector('.why-item__visual');
      if (slot && !slot.children.length && panels[i]) {
        var clone = panels[i].cloneNode(true);
        clone.className = 'why-clone';
        slot.appendChild(clone);
      }
      item.querySelector('.why-item__btn').addEventListener('click', function () {
        if (mobile.matches && item.classList.contains('is-active')) activate(-1, false);
        else activate(i, false);
      });
    });

    var paused = false;
    var pause = function () {
      if (paused || mobile.matches) return;
      paused = true;
      clearTimeout(timer);
      items[current] && items[current].classList.remove('is-running');
    };
    var resume = function () {
      if (!paused || mobile.matches) return;
      paused = false;
      if (current >= 0) activate(current, true);
    };
    why.addEventListener('mouseenter', pause);
    why.addEventListener('mouseleave', function () { if (!why.contains(document.activeElement)) resume(); });
    why.addEventListener('focusin', pause);
    why.addEventListener('focusout', function (e) { if (!why.contains(e.relatedTarget) && !why.matches(':hover')) resume(); });

    var start = function () { activate(0, !mobile.matches); };
    if (mobile.addEventListener) mobile.addEventListener('change', start);
    start();
  }

  var faq = document.querySelector('[data-faq]');
  if (faq) {
    faq.addEventListener('click', function (e) {
      var btn = e.target.closest('.faq-item__q');
      if (!btn) return;
      var item = btn.parentElement;
      var open = !item.classList.contains('is-open');
      faq.querySelectorAll('.faq-item').forEach(function (other) {
        other.classList.remove('is-open');
        other.querySelector('.faq-item__q').setAttribute('aria-expanded', 'false');
      });
      item.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', String(open));
    });
  }
})();
