(function () {
  var planSwitch = document.querySelector('.plan-switch');
  if (planSwitch) {
    var expandComboPill = function () {
      planSwitch.classList.remove('plan-switch--s1', 'plan-switch--s2');
    };

    var switchTab = function (tab) {
      expandComboPill();
      planSwitch.querySelectorAll('.plan-switch__tab').forEach(function (btn) {
        var on = btn.dataset.tab === tab;
        btn.classList.toggle('is-active', on);
        btn.setAttribute('aria-selected', String(on));
      });
      document.querySelectorAll('[data-tab-show]').forEach(function (el) {
        el.classList.toggle('hidden', el.dataset.tabShow !== tab);
      });
      document.querySelectorAll('.tab-panel').forEach(function (panel) {
        var active = panel.dataset.panel === tab;
        panel.classList.toggle('is-active', active);
        if (active) {
          panel.classList.remove('panel-anim');
          void panel.offsetWidth;
          panel.classList.add('panel-anim');
        }
      });
    };

    planSwitch.querySelectorAll('.plan-switch__tab').forEach(function (btn) {
      btn.addEventListener('click', function () { switchTab(btn.dataset.tab); });
    });
    document.querySelectorAll('[data-open-tab]').forEach(function (link) {
      link.addEventListener('click', function () { switchTab(link.dataset.openTab); });
    });

    setTimeout(function () {
      if (planSwitch.classList.contains('plan-switch--s1')) {
        planSwitch.classList.remove('plan-switch--s1');
        planSwitch.classList.add('plan-switch--s2');
      }
    }, 1200);
    setTimeout(expandComboPill, 2800);
  }

  var why = document.querySelector('[data-why]');
  if (why) {
    var items = Array.prototype.slice.call(why.querySelectorAll('.why-item'));
    var panels = Array.prototype.slice.call(document.querySelectorAll('.why-panel'));
    var DELAY = 4000;
    var timer = null;
    var current = 0;
    var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    why.style.setProperty('--why-delay', DELAY + 'ms');

    var activate = function (index, autoplay) {
      items.forEach(function (item, i) {
        item.classList.toggle('is-active', i === index);
        item.classList.remove('is-running');
      });
      panels.forEach(function (panel, i) { panel.classList.toggle('is-active', i === index); });
      current = index;
      clearTimeout(timer);
      if (!autoplay || reduceMotion) return;
      void items[index].offsetWidth;
      items[index].classList.add('is-running');
      timer = setTimeout(function () { activate((current + 1) % items.length, true); }, DELAY);
    };

    var mobile = window.matchMedia('(max-width: 767.98px)');

    items.forEach(function (item, i) {
      var slot = item.querySelector('.why-item__visual');
      if (slot && !slot.children.length && panels[i]) {
        var clone = panels[i].cloneNode(true);
        clone.className = 'why-clone';
        slot.appendChild(clone);
      }
      item.querySelector('.why-item__btn').addEventListener('click', function () {
        if (mobile.matches && item.classList.contains('is-active')) activate(-1, false);
        else activate(i, false);
      });
    });

    var start = function () { activate(0, !mobile.matches); };
    if (mobile.addEventListener) mobile.addEventListener('change', start);
    start();
  }

  var faq = document.querySelector('[data-faq]');
  if (faq) {
    faq.addEventListener('click', function (e) {
      var btn = e.target.closest('.faq-item__q');
      if (!btn) return;
      var item = btn.parentElement;
      var open = !item.classList.contains('is-open');
      faq.querySelectorAll('.faq-item').forEach(function (other) {
        other.classList.remove('is-open');
        other.querySelector('.faq-item__q').setAttribute('aria-expanded', 'false');
      });
      item.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', String(open));
    });
  }
})();
