// Account tabs: show the panel matching the clicked tab (or the URL hash on load).
(function () {
  var tabs = document.querySelectorAll('[data-tab]');
  // Scroll the tab strip so the active tab sits in the middle (mobile/tablet overflow).
  function center(t) {
    var ul = t.closest('ul');
    var li = t.parentElement;
    ul.scrollTo({ left: li.offsetLeft - ul.offsetLeft + li.offsetWidth / 2 - ul.clientWidth / 2, behavior: 'smooth' });
  }
  function show(id) {
    if (!document.getElementById(id)) return;
    tabs.forEach(function (t) {
      if (t.dataset.tab === id) { t.setAttribute('aria-current', 'page'); center(t); }
      else t.removeAttribute('aria-current');
    });
    document.querySelectorAll('[data-panel]').forEach(function (p) { p.hidden = p.id !== id; });
  }
  tabs.forEach(function (t) {
    t.addEventListener('click', function (e) {
      e.preventDefault();
      show(t.dataset.tab);
      history.replaceState(null, '', '#' + t.dataset.tab);
    });
  });
  if (location.hash) show(location.hash.slice(1));
})();

// Nominee: empty -> form -> saved view (edit/remove), PAN show/hide, validation.
(function () {
  var empty = document.querySelector('[data-nominee-empty]');
  var form = document.querySelector('[data-nominee-form]');
  if (!empty || !form) return;
  var view = document.querySelector('[data-nominee-view]');
  var actions = document.querySelector('[data-nominee-actions]');
  var banner = document.querySelector('[data-nominee-banner]');
  var removed = document.querySelector('[data-nominee-removed]');
  document.querySelectorAll('[data-banner-close]').forEach(function (b) { b.addEventListener('click', function () { b.parentNode.hidden = true; }); });
  var badge = document.querySelector('[data-nominee-badge]');
  var saved = null; // ponytail: in-page state only; swap for the API response when wired.

  // state: 'empty' | 'form' | 'view'
  function show(state, focusEl) {
    empty.hidden = state !== 'empty';
    form.hidden = state !== 'form';
    view.hidden = actions.hidden = state !== 'view';
    if (state !== 'view') banner.hidden = true;
    if (state !== 'empty') removed.hidden = true;
    showFail(false);
    showRemoveFail(false);
    if (badge) badge.hidden = !!saved; // dot only while no nominee is added
    if (focusEl) focusEl.focus();
  }
  // Form mode: 'add' (empty → new nominee) or 'edit' (change saved nominee; Save disabled until something changes).
  var help = form.querySelector('[data-nominee-help]');
  var submit = form.querySelector('[data-nominee-submit]');
  var KEYS = ['name', 'dob', 'pan', 'mobile', 'email', 'relationship'];
  function setMode(mode) {
    var edit = mode === 'edit';
    form.dataset.mode = mode;
    help.textContent = (edit ? 'Update' : 'Enter') + ' the details of your nominee, not your own. All fields are required.';
    submit.textContent = edit ? 'Save Changes' : 'Save Details';
    // PAN starts visible (add and edit); the eye masks it.
    var pan = document.getElementById('nm-pan');
    var eye = form.querySelector('[data-pan-toggle]');
    pan.type = 'text';
    eye.setAttribute('aria-pressed', 'true');
    eye.setAttribute('aria-label', 'Hide PAN');
    syncDirty();
  }
  function syncDirty() {
    submit.disabled = form.dataset.mode === 'edit' && KEYS.every(function (k) { return form.elements[k].value.trim() === saved[k]; });
  }
  form.addEventListener('input', syncDirty);
  form.addEventListener('change', syncDirty);

  document.querySelector('[data-nominee-add]').addEventListener('click', function () {
    setMode('add');
    show('form', form.querySelector('input'));
  });
  document.querySelector('[data-nominee-cancel]').addEventListener('click', function () {
    form.reset();
    if (saved) { fill(saved); show('view', document.querySelector('[data-nominee-edit]')); }
    else show('empty', document.querySelector('[data-nominee-add]'));
  });
  document.querySelector('[data-nominee-edit]').addEventListener('click', function () {
    fill(saved);
    setMode('edit');
    show('form', form.querySelector('input'));
  });
  // Remove failed: inline banner (desktop) + bottom toast (mobile); dev calls showRemoveFail(true) when the remove API fails.
  var removeFail = document.querySelector('[data-remove-fail]');
  var removeFailToast = document.querySelector('[data-remove-fail-toast]');
  function showRemoveFail(on) { removeFail.hidden = removeFailToast.hidden = !on; }
  document.querySelectorAll('[data-remove-fail-close]').forEach(function (b) { b.addEventListener('click', function () { showRemoveFail(false); }); });

  // Remove: confirmation dialog (native <dialog>: Esc, focus trap and backdrop come free).
  var removeBtn = document.querySelector('[data-nominee-remove]');
  var removeDlg = document.querySelector('[data-remove-dialog]');
  function openRemove() {
    removeDlg.querySelector('[data-remove-name]').textContent = saved.name;
    showRemoveFail(false);
    removeDlg.showModal();
    removeDlg.classList.add('is-opening');
  }
  removeDlg.addEventListener('animationend', function () { removeDlg.classList.remove('is-opening'); });
  removeBtn.addEventListener('click', openRemove);
  removeDlg.querySelector('[data-remove-cancel]').addEventListener('click', function () { removeDlg.close(); });
  removeDlg.addEventListener('close', function () { if (saved) removeBtn.focus(); });
  removeDlg.querySelector('[data-remove-confirm]').addEventListener('click', function () {
    saved = null; // ponytail: wire the remove API here; on failure keep saved and show an error.
    removeDlg.close();
    form.reset();
    show('empty', document.querySelector('[data-nominee-add]'));
    showRemoved();
  });
  function showRemoved() {
    removed.hidden = false;
    showToast('Nominee removed successfully');
  }

  // Save failed: inline banner (desktop) + bottom toast with Try Again (mobile).
  var fail = form.querySelector('[data-nominee-fail]');
  var failToast = document.querySelector('[data-nominee-fail-toast]');
  function showFail(on) {
    fail.hidden = !on;
    if (failToast) failToast.hidden = !on;
  }
  document.querySelectorAll('[data-nominee-fail-close]').forEach(function (b) { b.addEventListener('click', function () { showFail(false); }); });

  // Put saved values back into the form (used when cancelling an edit).
  function fill(d) {
    KEYS.forEach(function (k) { form.elements[k].value = d[k]; });
  }

  // Saved view
  var panVal = view.querySelector('[data-v="pan"]');
  var viewEye = view.querySelector('[data-view-pan-toggle]');
  function render(d) {
    var p = d.dob.split('-');
    var out = {
      name: d.name,
      dob: p[2] + '/' + p[1] + '/' + p[0],
      pan: 'XXXXX' + d.pan.slice(5),
      mobile: d.mobile,
      mobileSpaced: d.mobile.slice(0, 5) + ' ' + d.mobile.slice(5),
      email: d.email,
      relationship: d.relationship
    };
    view.querySelectorAll('[data-v]').forEach(function (el) { el.textContent = out[el.dataset.v]; });
    viewEye.setAttribute('aria-pressed', 'false');
    viewEye.setAttribute('aria-label', 'Show PAN');
  }
  viewEye.addEventListener('click', function () {
    var showing = viewEye.getAttribute('aria-pressed') !== 'true';
    panVal.textContent = showing ? saved.pan : 'XXXXX' + saved.pan.slice(5);
    viewEye.setAttribute('aria-pressed', String(showing));
    viewEye.setAttribute('aria-label', showing ? 'Hide PAN' : 'Show PAN');
  });

  // Mobile toast: auto-dismiss after 4s (CSS hides it on desktop; desktop uses the inline banner).
  var toast = document.querySelector('[data-nominee-toast]');
  var toastTimer;
  function showToast(title, sub) {
    if (!toast) return;
    toast.querySelector('[data-toast-title]').textContent = title;
    var subEl = toast.querySelector('[data-toast-sub]');
    subEl.textContent = sub || '';
    subEl.hidden = !sub;
    toast.classList.toggle('is-plain', !sub); // single-line toast (saved)
    clearTimeout(toastTimer);
    toast.classList.remove('is-leaving');
    toast.hidden = false;
    toast.classList.add('is-entering');
    toastTimer = setTimeout(function () {
      toast.classList.remove('is-entering');
      toast.classList.add('is-leaving');
      toastTimer = setTimeout(function () { toast.classList.remove('is-leaving'); toast.hidden = true; }, 250);
    }, 4000);
  }
  // Validation: native constraints (required/pattern/min/max); message comes from data-error.
  var fields = Array.prototype.slice.call(form.querySelectorAll('[data-error]'));
  var dob = document.getElementById('nm-dob');
  // DOB: native date picker, no future dates; open the calendar on any click, not just the icon.
  var now = new Date();
  dob.max = new Date(now - now.getTimezoneOffset() * 60000).toISOString().slice(0, 10); // local today
  dob.addEventListener('click', function () { try { dob.showPicker(); } catch (e) {} });
  // Input sanitising: PAN upper-case only (exactly 10 chars via pattern/maxlength), mobile digits only, name letters/space/./' only.
  function sanitise(id, fn) {
    var el = document.getElementById(id);
    el.addEventListener('input', function () {
      var v = fn(el.value);
      if (v !== el.value) el.value = v;
    });
  }
  sanitise('nm-pan', function (v) { return v.toUpperCase(); });
  sanitise('nm-mobile', function (v) { return v.replace(/\D/g, ''); });
  sanitise('nm-name', function (v) { return v.replace(/[^A-Za-z .']/g, '').replace(/\s{2,}/g, ' '); });
  function check(f) {
    var ok = f.checkValidity();
    var err = document.getElementById(f.id + '-error');
    if (!ok && !err) {
      err = document.createElement('p');
      err.className = 'field__error';
      err.id = f.id + '-error';
      f.closest('.field').appendChild(err);
    }
    // Custom (server) message wins over the field's default data-error text.
    if (err) err.textContent = f.validity.customError ? f.validationMessage : f.dataset.error;
    if (err) err.hidden = ok;
    f.classList.toggle('is-invalid', !ok);
    f.setAttribute('aria-invalid', String(!ok));
    if (ok) f.removeAttribute('aria-describedby'); else f.setAttribute('aria-describedby', err.id);
    return ok;
  }
  fields.forEach(function (f) {
    f.addEventListener(f.tagName === 'SELECT' ? 'change' : 'input', function () {
      f.setCustomValidity(''); // editing clears a server error (e.g. self-nomination)
      if (f.classList.contains('is-invalid')) check(f);
    });
  });
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    fields.forEach(function (f) { if (f.tagName === 'INPUT' && f.type !== 'date') f.value = f.value.trim(); });
    var bad = fields.filter(function (f) { return !check(f); });
    if (bad.length) { bad[0].focus(); return; }
    saved = {};
    KEYS.forEach(function (k) { saved[k] = form.elements[k].value; });
    render(saved);
    show('view');
    banner.hidden = false;
    showToast('Nominee details saved successfully.');
    document.getElementById('nominee-title').scrollIntoView({ block: 'nearest' });
  });
  form.addEventListener('reset', function () {
    fields.forEach(function (f) {
      f.setCustomValidity('');
      f.classList.remove('is-invalid');
      f.removeAttribute('aria-invalid');
      f.removeAttribute('aria-describedby');
      var err = document.getElementById(f.id + '-error');
      if (err) err.hidden = true;
    });
  });

  var eye = form.querySelector('[data-pan-toggle]');
  var pan = document.getElementById('nm-pan');
  eye.addEventListener('click', function () {
    var show = pan.type === 'password';
    pan.type = show ? 'text' : 'password';
    eye.setAttribute('aria-pressed', String(show));
    eye.setAttribute('aria-label', show ? 'Hide PAN' : 'Show PAN');
  });

  // Relationship dropdown: custom menu built from the <select>'s options; the select stays the form value.
  var rel = document.getElementById('nm-rel');
  var menu = document.createElement('ul');
  menu.className = 'field__menu';
  menu.id = 'nm-rel-menu';
  menu.setAttribute('role', 'listbox');
  menu.hidden = true;
  var items = Array.prototype.slice.call(rel.options, 1).map(function (o, i) {
    var li = document.createElement('li');
    li.id = 'nm-rel-opt-' + i;
    li.setAttribute('role', 'option');
    li.textContent = o.text;
    menu.appendChild(li);
    return li;
  });
  rel.parentNode.appendChild(menu);
  rel.setAttribute('aria-controls', menu.id);
  rel.setAttribute('aria-expanded', 'false');
  var active = 0;
  function setActive(i) {
    active = i;
    items.forEach(function (li, j) { li.classList.toggle('is-active', j === i); li.setAttribute('aria-selected', String(j === i)); });
    rel.setAttribute('aria-activedescendant', items[i].id);
  }
  function openMenu() { menu.hidden = false; rel.setAttribute('aria-expanded', 'true'); setActive(Math.max(0, rel.selectedIndex - 1)); }
  function closeMenu() { menu.hidden = true; rel.setAttribute('aria-expanded', 'false'); rel.removeAttribute('aria-activedescendant'); }
  function pick(i) {
    rel.selectedIndex = i + 1;
    rel.dispatchEvent(new Event('change', { bubbles: true }));
    closeMenu();
  }
  // Block the native picker (mouse + touch) and toggle ours instead.
  rel.addEventListener('touchstart', function (e) { e.preventDefault(); }, { passive: false });
  rel.addEventListener('pointerdown', function (e) {
    e.preventDefault();
    rel.focus();
    if (menu.hidden) openMenu(); else closeMenu();
  });
  rel.addEventListener('keydown', function (e) {
    var k = e.key;
    if (menu.hidden) {
      if (k === 'Enter' || k === ' ' || k === 'ArrowDown' || k === 'ArrowUp') { e.preventDefault(); openMenu(); }
      return;
    }
    if (k === 'ArrowDown') { e.preventDefault(); setActive(Math.min(active + 1, items.length - 1)); }
    else if (k === 'ArrowUp') { e.preventDefault(); setActive(Math.max(active - 1, 0)); }
    else if (k === 'Enter' || k === ' ') { e.preventDefault(); pick(active); }
    else if (k === 'Escape') { e.preventDefault(); closeMenu(); }
    else if (k === 'Tab') closeMenu();
  });
  rel.addEventListener('blur', closeMenu);
  menu.addEventListener('pointerdown', function (e) { e.preventDefault(); }); // keep focus on the select
  items.forEach(function (li, i) {
    li.addEventListener('pointerenter', function () { setActive(i); });
    li.addEventListener('click', function () { pick(i); });
  });

  // Server-side errors: errs = { fieldName: message }. Self-nomination = nominee PAN/mobile/email match the user's own account.
  function serverErrors(errs) {
    Object.keys(errs).forEach(function (k) { form.elements[k].setCustomValidity(errs[k]); check(form.elements[k]); });
  }

  // Starting state per page: <body data-nominee-start="form|errors|self|success|edit|failed">; none = empty state.
  var SAMPLE = { name: 'Priya Sharma', dob: '1990-03-14', pan: 'ABCDE1234F', mobile: '9876543210', email: 'priya.sharma@example.com', relationship: 'Spouse' };
  var start = document.body.dataset.nomineeStart;
  if (start === 'removed') showRemoved();
  if (start === 'form') { setMode('add'); show('form'); }
  if (start === 'errors') {
    setMode('add');
    show('form');
    fill({ name: '', dob: '', pan: 'ABCDE123', mobile: '98765', email: 'priya.sharma@', relationship: '' });
    fields.forEach(check);
  }
  if (start === 'self') {
    // ponytail: demo only; the API decides self-nomination (front-end has no own-account PAN/mobile/email).
    setMode('add');
    show('form');
    fill({ name: 'Rahul Verma', dob: '1985-08-22', pan: 'ABCDE1234F', mobile: '9876543210', email: 'priya.sharma@example.com', relationship: 'Spouse' });
    serverErrors({
      pan: 'This PAN matches your own account. Enter your nominee\'s PAN.',
      mobile: 'This mobile number matches your own account. Enter your nominee\'s mobile number.',
      email: 'This email address matches your own account. Enter your nominee\'s email address.'
    });
  }
  if (start === 'success' || start === 'edit' || start === 'failed' || start === 'remove' || start === 'removefail' || start === 'view' || start === 'editerrors') {
    saved = {};
    KEYS.forEach(function (k) { saved[k] = SAMPLE[k]; });
    fill(saved);
    render(saved);
    if (start === 'success') { show('view'); banner.hidden = false; showToast('Nominee details saved successfully.'); }
    else if (start === 'remove') { show('view'); openRemove(); }
    else if (start === 'removefail') { show('view'); showRemoveFail(true); }
    else if (start === 'view') show('view');
    else { setMode('edit'); show('form'); }
    if (start === 'editerrors') {
      // Figma example: name cleared, mobile shortened.
      form.elements.name.value = '';
      form.elements.mobile.value = '98765';
      syncDirty();
      check(form.elements.name);
      check(form.elements.mobile);
    }
    if (start === 'failed') {
      // Figma example: email was changed, the save request failed.
      form.elements.email.value = 'priya.s@example.com';
      syncDirty();
      showFail(true);
    }
  }
})();
