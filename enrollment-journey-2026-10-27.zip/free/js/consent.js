/*
 * Consent section + Privacy Notice popup.
 * Mount: <div class="cc-consent" data-cta="ID-of-submit-button"></div>
 * Consents unlock only after the notice is read to the end; the submit button
 * unlocks once every required consent is ticked (recommended ones are optional).
 */
(function () {
  // Content lives in content/consent-en.txt and content/consent-hi.txt (see the notes at the top of those files).
  var CONTENT = { en: null, hi: null };

  function parseContent(text) {
    var out = { required: [], recommended: [], notice: [] }, section = null;
    text.split(/\r?\n/).forEach(function (raw) {
      var line = raw.trim();
      if (/^\s+- /.test(raw)) line = '  ' + line; // keep nested-bullet indent
      if (!line || line.indexOf('//') === 0) return;
      var m = line.match(/^\[(required|recommended|notice)\]$/i);
      if (m) { section = m[1].toLowerCase(); return; }
      if (section) out[section].push(line);
    });
    return out;
  }

  // Notice markup: "## " heading, "### " sub-heading, "- " bullet, "  - " nested bullet,
  // "| a | b |" table row (first row of a table = header), "== " closing line, else paragraph.
  function noticeHTML(lines) {
    var html = '', list = 0, table = false;
    function closeList(to) { while (list > to) { html += '</li></ul>'; list--; } }
    lines.forEach(function (line) {
      var depth = line.indexOf('  - ') === 0 ? 2 : line.indexOf('- ') === 0 ? 1 : 0;
      if (depth) {
        if (depth > list) { html += '<ul>'; list++; } else { closeList(depth); html += '</li>'; }
        html += '<li>' + line.slice(depth * 2);
        return;
      }
      closeList(0);
      if (line.indexOf('| ') === 0) {
        var cells = line.replace(/^\|\s*|\s*\|$/g, '').split(/\s*\|\s*/), tag = table ? 'td' : 'th';
        if (!table) { html += '<div class="cc-table"><table>'; table = true; }
        html += '<tr><' + tag + '>' + cells.join('</' + tag + '><' + tag + '>') + '</' + tag + '></tr>';
        return;
      }
      if (table) { html += '</table></div>'; table = false; }
      if (line.indexOf('### ') === 0) html += '<h4>' + line.slice(4) + '</h4>';
      else if (line.indexOf('## ') === 0) html += '<h3>' + line.slice(3) + '</h3>';
      else if (line.indexOf('== ') === 0 || line.indexOf('-- ') === 0) html += '<p class="cc-end">' + line.slice(3) + '</p>';
      else html += '<p>' + line + '</p>';
    });
    closeList(0);
    if (table) html += '</table></div>';
    return html;
  }

  function contentFor(lang) {
    var c = CONTENT[lang] || CONTENT.en;
    return {
      required: c.required.length ? c.required : CONTENT.en.required,
      recommended: c.recommended.length ? c.recommended : CONTENT.en.recommended,
      notice: c.notice.length ? c.notice : CONTENT.en.notice
    };
  }

  function load(lang) {
    return fetch('content/consent-' + lang + '.txt', { cache: 'no-cache' })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.text(); })
      .then(function (t) { CONTENT[lang] = parseContent(t); });
  }

  var modal, scrollArea, hint, doneBtn, onDone, fontLoaded;

  function loadDevanagariFont() {
    if (fontLoaded) return;
    fontLoaded = true;
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500&display=swap';
    document.head.appendChild(link);
  }

  function buildModal() {
    modal = document.createElement('dialog');
    modal.className = 'cc-modal';
    modal.setAttribute('aria-labelledby', 'ccModalTitle');
    modal.innerHTML =
      '<div class="cc-modal-head">' +
        '<img class="cc-modal-logo" src="./images/logo.svg" alt="CIBIL">' +
        '<h2 class="cc-modal-title" id="ccModalTitle">Privacy Notice</h2>' +
        '<button type="button" class="cc-modal-close" aria-label="Close">' +
          '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="#262626"/></svg>' +
        '</button>' +
      '</div>' +
      '<div class="cc-scroll" tabindex="0"></div>' +
      '<div class="cc-modal-foot">' +
        '<p class="cc-modal-hint" aria-live="polite">Scroll to the end to continue</p>' +
        '<button type="button" class="cc-done" disabled>Done</button>' +
      '</div>';
    document.body.appendChild(modal);
    scrollArea = modal.querySelector('.cc-scroll');
    hint = modal.querySelector('.cc-modal-hint');
    doneBtn = modal.querySelector('.cc-done');
    scrollArea.addEventListener('scroll', checkEnd);
    modal.querySelector('.cc-modal-close').addEventListener('click', function () { modal.close(); });
    doneBtn.addEventListener('click', function () {
      modal.close();
      if (onDone) onDone();
    });
  }

  function checkEnd() {
    if (scrollArea.scrollTop + scrollArea.clientHeight < scrollArea.scrollHeight - 4) return;
    doneBtn.disabled = false;
    hint.textContent = '✓ You’ve reached the end of the notice';
    hint.classList.add('is-done');
  }

  function openNotice(lang, alreadyRead, callback) {
    if (!modal) buildModal();
    scrollArea.innerHTML = '<p class="cc-scroll-title" lang="en" aria-hidden="true">Privacy Notice</p>' + noticeHTML(contentFor(lang).notice); // title repeated in scroll for mobile layout
    scrollArea.lang = (lang === 'hi' && CONTENT.hi && CONTENT.hi.notice.length) ? 'hi' : 'en';
    onDone = callback;
    doneBtn.disabled = !alreadyRead;
    hint.textContent = alreadyRead ? '✓ You’ve reached the end of the notice' : 'Scroll to the end to continue';
    hint.classList.toggle('is-done', alreadyRead);
    modal.showModal();
    scrollArea.scrollTop = 0;
    checkEnd(); // short screens: notice may already fit
  }

  function itemHTML(id, text) {
    return '<label class="cc-item" for="' + id + '">' +
             '<input type="checkbox" id="' + id + '" aria-disabled="true">' +
             '<span class="cc-text">' + text + '</span>' +
           '</label>';
  }

  function init(root, n) {
    var html =
      '<div class="cc-head">' +
        '<p class="cc-title">Your Consents</p>' +
        '<label class="cc-lang">Language <select aria-label="Consent language"><option value="en">English</option><option value="hi" lang="hi">हिन्दी</option></select></label>' +
      '</div>' +
      '<div class="cc-notice">' +
        '<div class="cc-notice-row">' +
          '<div class="cc-notice-top"><span class="cc-notice-name">Privacy Notice · Version 1.0</span><span class="cc-chip">Not reviewed</span></div>' +
          '<button type="button" class="cc-read-again">Read Again</button>' +
        '</div>' +
        '<p class="cc-notice-help">Read the full notice to enable the consents below.</p>' +
        '<button type="button" class="cc-read-btn">Read Privacy Notice</button>' +
      '</div>' +
      '<div class="cc-group"><p class="cc-group-title">Required to continue</p>' +
        CONTENT.en.required.map(function (t, i) { return itemHTML('cc' + n + 'req' + i, t); }).join('') +
      '</div>' +
      '<div class="cc-group"><p class="cc-group-title">Recommended</p>' +
        CONTENT.en.recommended.map(function (t, i) { return itemHTML('cc' + n + 'rec' + i, t); }).join('') +
      '</div>' +
      '<p class="cc-foot">You can review or withdraw your consents anytime from My Account → Manage Consents.</p>';
    root.innerHTML = html;

    var notice = root.querySelector('.cc-notice');
    var chip = root.querySelector('.cc-chip');
    var boxes = [].slice.call(root.querySelectorAll('.cc-item input'));
    var required = boxes.slice(0, CONTENT.en.required.length);
    var lang = 'en';
    var cta = document.getElementById(root.dataset.cta);
    var reviewed = false;
    var nudgeTimer;

    function updateCta() {
      if (!cta) return;
      var ok = reviewed && required.every(function (b) { return b.checked; });
      cta.classList.toggle('is-disabled', !ok);
      cta.setAttribute('aria-disabled', String(!ok));
    }

    function markReviewed() {
      reviewed = true;
      root.classList.add('is-reviewed');
      chip.textContent = '✓ Reviewed';
      boxes.forEach(function (b) { b.removeAttribute('aria-disabled'); });
      clearNudge();
      updateCta();
    }

    function clearNudge() {
      clearTimeout(nudgeTimer);
      notice.classList.remove('is-nudge');
      root.querySelectorAll('.cc-item.is-nudge').forEach(function (el) { el.classList.remove('is-nudge'); });
    }

    function nudge(item) {
      clearNudge();
      void notice.offsetWidth; // restart shake animation
      notice.classList.add('is-nudge');
      item.classList.add('is-nudge');
      notice.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      nudgeTimer = setTimeout(clearNudge, 2000);
    }

    boxes.forEach(function (b) {
      b.addEventListener('click', function (e) {
        if (reviewed) return;
        e.preventDefault();
        nudge(b.closest('.cc-item'));
      });
      b.addEventListener('change', updateCta);
    });

    var texts = [].slice.call(root.querySelectorAll('.cc-text'));
    root.querySelector('.cc-lang select').addEventListener('change', function () {
      lang = this.value;
      var hi = lang === 'hi';
      if (hi) loadDevanagariFont();
      var set = contentFor(lang);
      set.required.concat(set.recommended).forEach(function (t, i) {
        texts[i].innerHTML = t;
        texts[i].lang = hi ? 'hi' : 'en';
      });
      root.classList.toggle('is-hi', hi);
    });

    root.querySelector('.cc-read-btn').addEventListener('click', function () { openNotice(lang, false, markReviewed); });
    root.querySelector('.cc-read-again').addEventListener('click', function () { openNotice(lang, true, markReviewed); });

    updateCta();
  }

  var roots = document.querySelectorAll('.cc-consent');
  if (roots.length) {
    load('en')
      .then(function () { return load('hi').catch(function () {}); }) // no Hindi file: Hindi falls back to English
      .then(function () { [].forEach.call(roots, init); })
      .catch(function () {
        [].forEach.call(roots, function (root) {
          root.innerHTML = '<p class="cc-foot">Consents could not be loaded. Please refresh the page.</p>';
        });
      });
  }
})();
