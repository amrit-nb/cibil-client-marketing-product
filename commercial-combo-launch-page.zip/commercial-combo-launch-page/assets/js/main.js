(function () {
  var videoSeconds = 0;
  var pad = function (n) { return (n < 10 ? '0' : '') + n; };
  function applyDuration() {
    if (!videoSeconds) return;
    var h = Math.floor(videoSeconds / 3600);
    var m = Math.floor(videoSeconds % 3600 / 60);
    var sec = videoSeconds % 60;
    var label = h ? h + ':' + pad(m) + ':' + pad(sec) : m + ':' + pad(sec);
    document.querySelectorAll('[data-yt-duration]').forEach(function (n) { n.textContent = label; });
    document.querySelectorAll('[data-yt-minutes]').forEach(function (n) {
      n.textContent = Math.max(1, Math.floor(videoSeconds / 60));
    });
  }
  var planSwitch = document.querySelector('.plan-switch');
  if (planSwitch) {
    var expandComboPill = function () {
      planSwitch.classList.remove('plan-switch--s1', 'plan-switch--s2');
    };

    var PARAM = 'plan';
    var tabs = Array.prototype.map.call(planSwitch.querySelectorAll('.plan-switch__tab'), function (b) { return b.dataset.tab; });

    var switchTab = function (tab, updateUrl) {
      if (tabs.indexOf(tab) === -1) return;
      expandComboPill();
      if (updateUrl !== false) {
        try {
          var url = new URL(location.href);
          url.searchParams.set(PARAM, tab);
          history.replaceState(history.state, '', url);
        } catch (e) {}
      }
      planSwitch.querySelectorAll('.plan-switch__tab').forEach(function (btn) {
        var on = btn.dataset.tab === tab;
        btn.classList.toggle('is-active', on);
        btn.setAttribute('aria-selected', String(on));
        btn.tabIndex = on ? 0 : -1;
      });
      document.querySelectorAll('[data-tab-show]').forEach(function (el) {
        el.classList.toggle('hidden', el.dataset.tabShow !== tab);
      });
      document.querySelectorAll('.tab-panel').forEach(function (panel) {
        var active = panel.dataset.panel === tab;
        panel.classList.toggle('is-active', active);
        if (active) {
          panel.classList.remove('panel-anim');
          void panel.offsetWidth;
          panel.classList.add('panel-anim');
        }
      });
    };

    planSwitch.querySelectorAll('.plan-switch__tab').forEach(function (btn) {
      btn.addEventListener('click', function () { switchTab(btn.dataset.tab); });
    });
    planSwitch.addEventListener('keydown', function (e) {
      var i = tabs.indexOf(document.activeElement && document.activeElement.dataset.tab);
      if (i === -1) return;
      var next = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: tabs.length - 1 }[e.key];
      if (next === undefined) return;
      e.preventDefault();
      var tab = tabs[(next + tabs.length) % tabs.length];
      switchTab(tab);
      planSwitch.querySelector('[data-tab="' + tab + '"]').focus();
    });
    document.querySelectorAll('[data-open-tab]').forEach(function (link) {
      link.addEventListener('click', function () { switchTab(link.dataset.openTab); });
    });

    var initialTab = new URLSearchParams(location.search).get(PARAM);
    if (tabs.indexOf(initialTab) !== -1) {
      switchTab(initialTab, false);
      if (!location.hash) {
        requestAnimationFrame(function () { document.getElementById('plans').scrollIntoView(); });
      }
    }

    setTimeout(function () {
      if (planSwitch.classList.contains('plan-switch--s1')) {
        planSwitch.classList.remove('plan-switch--s1');
        planSwitch.classList.add('plan-switch--s2');
      }
    }, 1200);
    setTimeout(expandComboPill, 2800);
  }

  var why = document.querySelector('[data-why]');
  if (why) {
    var items = Array.prototype.slice.call(why.querySelectorAll('.why-item'));
    var panels = Array.prototype.slice.call(document.querySelectorAll('.why-panel'));
    var DELAY = 4000;
    var timer = null;
    var current = 0;
    var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    why.style.setProperty('--why-delay', DELAY + 'ms');

    var activate = function (index, autoplay) {
      items.forEach(function (item, i) {
        item.classList.toggle('is-active', i === index);
        item.classList.remove('is-running');
        item.querySelector('.why-item__btn').setAttribute('aria-expanded', String(i === index));
      });
      panels.forEach(function (panel, i) { panel.classList.toggle('is-active', i === index); });
      current = index;
      clearTimeout(timer);
      if (!autoplay || reduceMotion || paused) return;
      void items[index].offsetWidth;
      items[index].classList.add('is-running');
      timer = setTimeout(function () { activate((current + 1) % items.length, true); }, DELAY);
    };

    var mobile = window.matchMedia('(max-width: 767.98px)');

    items.forEach(function (item, i) {
      var slot = item.querySelector('.why-item__visual');
      if (slot && !slot.children.length && panels[i]) {
        var clone = panels[i].cloneNode(true);
        clone.className = 'why-clone';
        slot.appendChild(clone);
      }
      item.querySelector('.why-item__btn').addEventListener('click', function () {
        if (mobile.matches && item.classList.contains('is-active')) activate(-1, false);
        else activate(i, false);
      });
    });

    var paused = false;
    var pause = function () {
      if (paused || mobile.matches) return;
      paused = true;
      clearTimeout(timer);
      items[current] && items[current].classList.remove('is-running');
    };
    var resume = function () {
      if (!paused || mobile.matches) return;
      paused = false;
      if (current >= 0) activate(current, true);
    };
    why.addEventListener('mouseenter', pause);
    why.addEventListener('mouseleave', function () { if (!why.contains(document.activeElement)) resume(); });
    why.addEventListener('focusin', pause);
    why.addEventListener('focusout', function (e) { if (!why.contains(e.relatedTarget) && !why.matches(':hover')) resume(); });

    var start = function () { activate(0, !mobile.matches); };
    if (mobile.addEventListener) mobile.addEventListener('change', start);
    start();
  }

  var toggle = document.querySelector('.transcript-toggle');
  if (toggle) {
    var panel = document.getElementById(toggle.getAttribute('aria-controls'));
    var label = toggle.querySelector('.transcript-toggle__label');
    toggle.addEventListener('click', function () {
      var open = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', String(open));
      panel.classList.toggle('is-open', open);
      label.textContent = open ? 'Hide video transcript' : 'Read video transcript';
    });
  }

  // Transcript format (assets/transcript.txt):
  //   # Header meta        — shown top-right of the panel
  //   ## Group title       — starts a new group
  //   m:ss | Line text     — a row; lines wrapped in [ ] render muted
  // The HTML ships the same transcript as a fallback for when the file can't be fetched (e.g. opened via file://).
  var transcriptBody = document.querySelector('[data-transcript-src]');
  if (transcriptBody) {
    var meta = document.querySelector('.transcript__meta');
    var el = function (tag, cls, text) {
      var n = document.createElement(tag);
      if (cls) n.className = cls;
      if (text) n.textContent = text;
      return n;
    };
    fetch(transcriptBody.dataset.transcriptSrc)
      .then(function (res) { if (!res.ok) throw new Error(res.status); return res.text(); })
      .then(function (text) {
        if (!text.trim()) return;
        transcriptBody.textContent = '';
        var group = null;
        text.split(/\r?\n/).forEach(function (raw) {
          var line = raw.trim();
          if (!line) return;
          if (line.indexOf('## ') === 0) {
            group = el('div', 'transcript__group');
            group.appendChild(el('h3', '', line.slice(3)));
            transcriptBody.appendChild(group);
          } else if (line.indexOf('# ') === 0) {
            if (meta) {
              var head = line.slice(2).match(/^(.*?)\s*·\s*(\d+:\d{2}(?::\d{2})?)$/);
              meta.textContent = head ? head[1] + ' · ' : line.slice(2);
              if (head) meta.appendChild(el('span', '', head[2])).setAttribute('data-yt-duration', '');
              applyDuration();
            }
          } else {
            var parts = line.split('|');
            var time = parts.length > 1 ? parts.shift().trim() : '';
            var body = parts.join('|').trim();
            var row = el('p', 'transcript__row' + (/^\[.*\]$/.test(body) ? ' is-muted' : ''));
            row.appendChild(el('span', '', time));
            row.appendChild(document.createTextNode(body));
            if (!group) {
              group = el('div', 'transcript__group');
              transcriptBody.appendChild(group);
            }
            group.appendChild(row);
          }
        });
      })
      .catch(function () {});
  }

  var poster = document.querySelector('.video-poster');
  var videoId = poster ? poster.dataset.youtubeId : '';
  var canEmbed = /^https?:$/.test(location.protocol);
  var player = null;
  var playerReady = false;
  var playQueued = false;

  if (poster && videoId) {
    poster.querySelector('.video-poster__play').addEventListener('click', function () {
      // YouTube rejects embeds without an HTTP(S) referrer (Error 153), e.g. when opened via file://
      if (!canEmbed) {
        window.open('https://www.youtube.com/watch?v=' + encodeURIComponent(videoId), '_blank', 'noopener');
        return;
      }
      poster.classList.add('is-playing');
      if (playerReady) { player.playVideo(); player.getIframe().focus(); }
      else playQueued = true;
    });

    if (canEmbed) {
      window.onYouTubeIframeAPIReady = function () {
        player = new YT.Player('enrollPlayer', {
          videoId: videoId,
          host: 'https://www.youtube-nocookie.com',
          playerVars: { rel: 0, playsinline: 1, origin: location.origin },
          events: {
            onReady: function (e) {
              playerReady = true;
              readDuration(e.target, 0);
              if (playQueued) { e.target.playVideo(); e.target.getIframe().focus(); }
            }
          }
        });
      };
      var api = document.createElement('script');
      api.src = 'https://www.youtube.com/iframe_api';
      document.head.appendChild(api);
    }
  }

  function readDuration(p, tries) {
    var sec = Math.round(p.getDuration() || 0);
    if (sec > 0) { videoSeconds = sec; applyDuration(); }
    else if (tries < 10) setTimeout(function () { readDuration(p, tries + 1); }, 500);
  }

  var faq = document.querySelector('[data-faq]');
  if (faq) {
    faq.addEventListener('click', function (e) {
      var btn = e.target.closest('.faq-item__q');
      if (!btn) return;
      var item = btn.parentElement;
      var open = !item.classList.contains('is-open');
      faq.querySelectorAll('.faq-item').forEach(function (other) {
        other.classList.remove('is-open');
        other.querySelector('.faq-item__q').setAttribute('aria-expanded', 'false');
      });
      item.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', String(open));
    });
  }
})();
