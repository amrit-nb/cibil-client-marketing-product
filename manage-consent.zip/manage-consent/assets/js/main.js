(function () {
  var panel = document.querySelector('[data-consents]');
  if (!panel) return;

  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  // Matches the design's format, e.g. "12 Oct 2026, 10:42 AM"
  function stamp(d) {
    var h = d.getHours() % 12 || 12;
    var m = (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
    return d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear() + ', ' + h + ':' + m + ' ' + (d.getHours() < 12 ? 'AM' : 'PM');
  }

  var bar = document.querySelector('[data-consent-bar]');
  var count = bar && bar.querySelector('[data-consent-count]');
  var noun = bar && bar.querySelector('[data-consent-noun]');
  var switches = Array.prototype.slice.call(panel.querySelectorAll('[role="switch"]'));

  // Saved state = what the server has. Turning a non-granted consent ON only
  // stages it ("Unsaved") until the user gives consent via the Privacy Notice.
  switches.forEach(function (sw) { sw.dataset.saved = sw.dataset.saved || sw.getAttribute('aria-checked'); });

  function key(sw) { return sw.getAttribute('aria-labelledby'); }

  function setUnsaved(sw, unsaved) {
    var k = key(sw);
    var row = sw.closest('.consent, .channel');
    var tag = document.getElementById(k + '-unsaved');
    row.classList.toggle('is-unsaved', unsaved);
    sw.classList.toggle('is-unsaved', unsaved);
    if (tag) tag.hidden = !unsaved;
    var ids = sw.getAttribute('aria-describedby').split(' ').filter(function (id) { return id !== k + '-unsaved'; });
    if (unsaved) ids.unshift(k + '-unsaved');
    sw.setAttribute('aria-describedby', ids.join(' '));
  }

  function updateBar() {
    if (!bar) return;
    var n = switches.filter(function (sw) { return sw.classList.contains('is-unsaved'); }).length;
    var show = n > 0;
    var visible = !bar.hidden && !bar.classList.contains('is-leaving');
    if (show && !visible) {
      bar.classList.remove('is-leaving');
      bar.hidden = false;
      bar.classList.add('is-entering');
    } else if (!show && visible) {
      bar.classList.remove('is-entering');
      bar.classList.add('is-leaving');
    }
    count.textContent = n;
    noun.textContent = n === 1 ? 'consent' : 'consents';
  }

  if (bar) {
    bar.addEventListener('animationend', function () {
      if (bar.classList.contains('is-leaving')) bar.hidden = true;
      bar.classList.remove('is-entering', 'is-leaving');
    });
  }

  // Privacy Notice dialog: opened from the sticky bar; DONE saves staged consents.
  var notice = document.getElementById('privacy-notice');
  var giveBtn = document.querySelector('[data-give-consent]');
  if (notice && giveBtn && typeof notice.showModal === 'function') {
    var scrollBox = notice.querySelector('[data-notice-scroll]');
    var doneBtn = notice.querySelector('[data-notice-done]');
    var hint = notice.querySelector('.notice__hint');

    var checkRead = function () {
      if (scrollBox.scrollTop + scrollBox.clientHeight >= scrollBox.scrollHeight - 4) {
        doneBtn.disabled = false;
        hint.innerHTML = '<span aria-hidden="true">✓ </span>You\'ve reached the end of the notice';
        hint.classList.add('is-done');
      }
    };
    var closeNotice = function () {
      if (!notice.open || notice.classList.contains('is-closing')) return;
      notice.classList.remove('is-opening');
      notice.classList.add('is-closing');
    };

    giveBtn.addEventListener('click', function () {
      doneBtn.disabled = true;
      hint.textContent = 'Scroll to the end of the notice to continue';
      hint.classList.remove('is-done');
      notice.classList.remove('is-closing');
      notice.showModal();
      // Reset only once rendered: scrollTop is ignored while the dialog is display:none.
      scrollBox.scrollTop = 0;
      notice.classList.add('is-opening');
      checkRead();
    });
    scrollBox.addEventListener('scroll', checkRead);
    notice.addEventListener('animationend', function (e) {
      if (e.target !== notice) return;
      if (notice.classList.contains('is-closing')) {
        notice.classList.remove('is-closing');
        notice.close();
        if (!bar.hidden && !bar.classList.contains('is-leaving')) giveBtn.focus();
        else document.getElementById('consents-title').focus({ preventScroll: true }); // keep user's scroll position
      } else {
        notice.classList.remove('is-opening');
      }
    });
    notice.addEventListener('cancel', function (e) { e.preventDefault(); closeNotice(); });
    notice.addEventListener('click', function (e) {
      if (e.target !== notice) return;
      var r = notice.getBoundingClientRect();
      var inside = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
      if (!inside) closeNotice();
    });
    notice.querySelector('[data-notice-close]').addEventListener('click', closeNotice);

    var success = panel.querySelector('[data-consent-success]');
    var alertBox = panel.querySelector('[data-consent-alert]');
    if (alertBox) alertBox.querySelector('[data-consent-alert-close]').addEventListener('click', function () {
      alertBox.hidden = true;
      document.getElementById('consents-title').focus();
    });
    success.querySelector('[data-consent-success-close]').addEventListener('click', function () {
      success.hidden = true;
      document.getElementById('consents-title').focus();
    });

    doneBtn.addEventListener('click', function () {
      var now = stamp(new Date());
      var n = 0;
      switches.forEach(function (sw) {
        if (!sw.classList.contains('is-unsaved')) return;
        n++;
        setUnsaved(sw, false);
        sw.dataset.saved = 'true';
        var status = document.getElementById(key(sw) + '-status');
        if (status) status.textContent = 'Consent granted on ' + now;
      });
      success.querySelector('[data-consent-success-title]').textContent = n + ' of ' + n + ' consent' + (n === 1 ? '' : 's') + ' granted';
      success.querySelector('[data-consent-success-sub]').textContent = 'Your consent preferences are saved. Last updated on ' + now + '.';
      success.hidden = false;
      showToast(n + ' of ' + n + ' consent' + (n === 1 ? '' : 's') + ' granted');
      if (alertBox) alertBox.hidden = true;
      updateBar();
      closeNotice();
    });
  }

  panel.addEventListener('click', function (e) {
    var sw = e.target.closest('[role="switch"]');
    if (!sw) return;
    var on = sw.getAttribute('aria-checked') !== 'true';
    sw.setAttribute('aria-checked', String(on));

    if (sw.dataset.saved === 'true' && !on) {
      // Withdrawing a granted consent needs confirmation first.
      sw.setAttribute('aria-checked', 'true');
      openWithdraw(sw);
      return;
    }
    setUnsaved(sw, on);
    updateBar();
  });

  // Mobile success toast: auto-dismisses after 4s (CSS hides it on desktop)
  var toast = document.querySelector('[data-consent-toast]');
  var toastTimer;
  function showToast(text) {
    if (!toast) return;
    clearTimeout(toastTimer);
    toast.querySelector('[data-consent-toast-title]').textContent = text;
    toast.classList.remove('is-leaving');
    toast.hidden = false;
    toast.classList.add('is-entering');
    toastTimer = setTimeout(function () {
      toast.classList.remove('is-entering');
      toast.classList.add('is-leaving');
      // Timer, not animationend: the toast is display:none on desktop.
      toastTimer = setTimeout(function () {
        toast.classList.remove('is-leaving');
        toast.hidden = true;
      }, 250);
    }, 4000);
  }

  // Withdraw confirmation dialog
  var wd = document.getElementById('withdraw-notice');
  var wdName = wd && wd.querySelector('[data-withdraw-name]');
  var wdSwitch = null;
  var wdReturn = null;

  function openWithdraw(sw) {
    wdSwitch = sw;
    wdReturn = sw;
    wdName.textContent = document.getElementById(key(sw)).textContent.trim();
    wd.classList.remove('is-closing');
    wd.showModal();
    wd.classList.add('is-opening');
    wd.querySelector('[data-withdraw-keep]').focus();
  }
  function closeWithdraw() {
    if (!wd.open || wd.classList.contains('is-closing')) return;
    wd.classList.remove('is-opening');
    wd.classList.add('is-closing');
  }
  var retry = panel.querySelector('[data-withdraw-retry]');
  if (retry) retry.addEventListener('click', function () {
    openWithdraw(panel.querySelector('[aria-labelledby="' + retry.dataset.withdrawRetry + '"]'));
  });

  if (wd) {
    wd.addEventListener('animationend', function (e) {
      if (e.target !== wd) return;
      if (wd.classList.contains('is-closing')) {
        wd.classList.remove('is-closing');
        wd.close();
        if (wdReturn) wdReturn.focus();
      } else {
        wd.classList.remove('is-opening');
      }
    });
    wd.addEventListener('cancel', function (e) { e.preventDefault(); closeWithdraw(); });
    wd.addEventListener('click', function (e) {
      if (e.target !== wd) return;
      var r = wd.getBoundingClientRect();
      if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) closeWithdraw();
    });
    wd.querySelector('[data-withdraw-keep]').addEventListener('click', closeWithdraw);
    wd.querySelector('[data-withdraw-confirm]').addEventListener('click', function () {
      var sw = wdSwitch;
      sw.setAttribute('aria-checked', 'false');
      sw.dataset.saved = 'false';
      var status = document.getElementById(key(sw) + '-status');
      if (status) status.textContent = 'Consent withdrawn on ' + stamp(new Date());
      var failBox = panel.querySelector('[data-consent-alert]');
      if (failBox) failBox.hidden = true;
      closeWithdraw();
    });
  }
})();

// Mobile/tablet: sidebar drawer + keep the active account tab in view
(function () {
  var sidebar = document.getElementById('sidebar');
  var toggle = document.querySelector('[data-menu-toggle]');
  var backdrop = document.querySelector('.sidebar-backdrop');
  if (sidebar && toggle) {
    var setOpen = function (open) {
      sidebar.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
      if (backdrop) backdrop.hidden = !open;
      var main = document.querySelector('.app__main');
      if (main) main.inert = open;
      if (open) sidebar.querySelector('.sidebar__close').focus();
      else toggle.focus();
    };
    toggle.addEventListener('click', function () { setOpen(!sidebar.classList.contains('is-open')); });
    document.querySelectorAll('[data-menu-close]').forEach(function (el) {
      el.addEventListener('click', function () { setOpen(false); });
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && sidebar.classList.contains('is-open')) setOpen(false);
    });
  }

  var activeTab = document.querySelector('.account-tab[aria-current="page"]');
  if (activeTab) {
    var list = activeTab.closest('ul');
    list.scrollLeft = activeTab.parentElement.offsetLeft + activeTab.offsetWidth - list.clientWidth;
  }
})();

// Language dropdown (button + listbox)
(function () {
  var dd = document.querySelector('[data-lang-dd]');
  if (!dd) return;
  var btn = dd.querySelector('.lang-dd__btn');
  var list = dd.querySelector('[role="listbox"]');
  var value = dd.querySelector('.lang-dd__value');
  var opts = Array.prototype.slice.call(list.querySelectorAll('[role="option"]'));
  var active = 0;

  function focusOpt(i) {
    active = (i + opts.length) % opts.length;
    opts.forEach(function (o, k) { o.classList.toggle('is-focused', k === active); });
    list.setAttribute('aria-activedescendant', opts[active].id);
    opts[active].scrollIntoView({ block: 'nearest' });
  }
  function open() {
    list.hidden = false;
    btn.setAttribute('aria-expanded', 'true');
    focusOpt(Math.max(0, opts.findIndex(function (o) { return o.getAttribute('aria-selected') === 'true'; })));
    list.focus();
  }
  function close(returnFocus) {
    list.hidden = true;
    btn.setAttribute('aria-expanded', 'false');
    list.removeAttribute('aria-activedescendant');
    if (returnFocus) btn.focus();
  }
  function choose(i) {
    opts.forEach(function (o, k) { o.setAttribute('aria-selected', String(k === i)); });
    value.textContent = opts[i].textContent;
    value.lang = opts[i].lang || '';
    dd.dispatchEvent(new CustomEvent('change', { detail: { value: opts[i].dataset.value } }));
    close(true);
  }

  btn.addEventListener('click', function () { list.hidden ? open() : close(true); });
  btn.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); open(); }
  });
  list.addEventListener('keydown', function (e) {
    var k = e.key;
    if (k === 'ArrowDown') focusOpt(active + 1);
    else if (k === 'ArrowUp') focusOpt(active - 1);
    else if (k === 'Home') focusOpt(0);
    else if (k === 'End') focusOpt(opts.length - 1);
    else if (k === 'Enter' || k === ' ') choose(active);
    else if (k === 'Escape') close(true);
    else if (k === 'Tab') { close(false); return; }
    else return;
    e.preventDefault();
  });
  opts.forEach(function (o, i) {
    o.addEventListener('mousemove', function () { if (active !== i) focusOpt(i); });
    o.addEventListener('click', function () { choose(i); });
  });
  document.addEventListener('click', function (e) { if (!dd.contains(e.target) && !list.hidden) close(false); });
})();

// Consent text translations: only the four consent descriptions switch language.
// Text lives in assets/data/consent-text.txt ([lang] sections of  key = text  lines).
(function () {
  var dd = document.querySelector('[data-lang-dd]');
  var els = document.querySelectorAll('[data-i18n]');
  if (!dd || !els.length || !window.fetch) return;
  var texts = {};
  var lang = 'en';

  function parse(txt) {
    var out = {}, cur = null;
    txt.split(/\r?\n/).forEach(function (line) {
      line = line.trim();
      if (!line || line[0] === '#') return;
      var sec = line.match(/^\[(\w+)\]$/);
      if (sec) { cur = out[sec[1]] = {}; return; }
      var eq = line.indexOf('=');
      if (cur && eq > 0) cur[line.slice(0, eq).trim()] = line.slice(eq + 1).trim();
    });
    return out;
  }
  function apply() {
    var t = texts[lang];
    if (!t) return;
    els.forEach(function (el) {
      if (t[el.dataset.i18n]) el.textContent = t[el.dataset.i18n];
      if (lang === 'en') el.removeAttribute('lang'); else el.lang = lang;
    });
  }

  // ponytail: HTML keeps the English text as a fallback if the file can't be loaded.
  fetch('assets/data/consent-text.txt')
    .then(function (r) { return r.ok ? r.text() : Promise.reject(r.status); })
    .then(function (txt) { texts = parse(txt); apply(); })
    .catch(function () {});

  dd.addEventListener('change', function (e) { lang = e.detail.value; apply(); });
})();
