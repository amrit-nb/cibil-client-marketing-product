/*
 * DPDPA "Your Consents" block for Create Enrollment (Figma 34219-17969).
 * Standalone: does not modify lib.min.js / main.min.js. Same behaviour as
 * enrollment-journey-revamp/login/consent.html:
 *   locked until the Privacy Notice is read → tapping a locked box nudges the notice card →
 *   notice popup (DONE unlocks at the end) → "Reviewed" → boxes enabled.
 * The existing Submit button is driven by main.min.js via the hidden #appConsent checkbox:
 * it is ticked only when the notice is reviewed AND every required consent is ticked.
 * Text: files/dpdpa/content/consent-en.txt and consent-hi.txt.
 */
(function () {
  var BASE = 'files/dpdpa/';

  /* ---------- Content (same file format as the login consent page) ---------- */
  var CONTENT = { en: null, hi: null };

  function parseContent(text) {
    var out = { required: [], recommended: [], notice: [] }, section = null;
    text.split(/\r?\n/).forEach(function (raw) {
      var line = raw.trim();
      if (/^\s+- /.test(raw)) line = '  ' + line; // keep nested-bullet indent
      if (!line || line.indexOf('//') === 0) return;
      var m = line.match(/^\[(required|recommended|notice)\]$/i);
      if (m) { section = m[1].toLowerCase(); return; }
      if (section) out[section].push(line);
    });
    return out;
  }

  // Notice markup: "## " heading, "### " sub-heading, "- " bullet, "  - " nested bullet,
  // "| a | b |" table row (first row = header), "== " closing line, else paragraph.
  function noticeHTML(lines) {
    var html = '', list = 0, table = false;
    function closeList(to) { while (list > to) { html += '</li></ul>'; list--; } }
    lines.forEach(function (line) {
      var depth = line.indexOf('  - ') === 0 ? 2 : line.indexOf('- ') === 0 ? 1 : 0;
      if (depth) {
        if (depth > list) { html += '<ul>'; list++; } else { closeList(depth); html += '</li>'; }
        html += '<li>' + line.slice(depth * 2);
        return;
      }
      closeList(0);
      if (line.indexOf('| ') === 0) {
        var cells = line.replace(/^\|\s*|\s*\|$/g, '').split(/\s*\|\s*/), tag = table ? 'td' : 'th';
        if (!table) { html += '<div class="dpn-table"><table>'; table = true; }
        html += '<tr><' + tag + '>' + cells.join('</' + tag + '><' + tag + '>') + '</' + tag + '></tr>';
        return;
      }
      if (table) { html += '</table></div>'; table = false; }
      if (line.indexOf('### ') === 0) html += '<h4>' + line.slice(4) + '</h4>';
      else if (line.indexOf('## ') === 0) html += '<h3>' + line.slice(3) + '</h3>';
      else if (line.indexOf('== ') === 0 || line.indexOf('-- ') === 0) html += '<p class="dpn-end">' + line.slice(3) + '</p>';
      else html += '<p>' + line + '</p>';
    });
    closeList(0);
    if (table) html += '</table></div>';
    return html;
  }

  function contentFor(lang) {
    var c = CONTENT[lang] || CONTENT.en, en = CONTENT.en;
    return {
      required: c.required.length ? c.required : en.required,
      recommended: c.recommended.length ? c.recommended : en.recommended,
      notice: c.notice.length ? c.notice : en.notice
    };
  }

  function load(lang) {
    return fetch(BASE + 'content/consent-' + lang + '.txt', { cache: 'no-cache' })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.text(); })
      .then(function (t) { CONTENT[lang] = parseContent(t); });
  }

  var fontLoaded = false;
  function loadDevanagariFont() {
    if (fontLoaded) return;
    fontLoaded = true;
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500&display=swap';
    document.head.appendChild(link);
  }

  /* ---------- Privacy Notice popup ---------- */
  var modal, scrollArea, hint, doneBtn, onDone;

  function buildModal() {
    modal = document.createElement('dialog');
    modal.className = 'dpn-modal';
    modal.setAttribute('aria-labelledby', 'dpnTitle');
    modal.innerHTML =
      '<div class="dpn-head">' +
        '<img class="dpn-logo" src="./files/cibil-logo.svg" alt="TransUnion CIBIL">' +
        '<h2 class="dpn-title" id="dpnTitle">Privacy Notice</h2>' +
        '<button type="button" class="dpn-close" aria-label="Close">' +
          '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="#262626"/></svg>' +
        '</button>' +
      '</div>' +
      '<div class="dpn-scroll" tabindex="0" role="region" aria-label="Privacy Notice text"></div>' +
      '<div class="dpn-foot">' +
        '<p class="dpn-hint" aria-live="polite">Scroll to the end of the notice to continue</p>' +
        '<button type="button" class="dpn-done" disabled>Done</button>' +
      '</div>';
    document.body.appendChild(modal);
    scrollArea = modal.querySelector('.dpn-scroll');
    hint = modal.querySelector('.dpn-hint');
    doneBtn = modal.querySelector('.dpn-done');
    scrollArea.addEventListener('scroll', checkEnd);
    modal.querySelector('.dpn-close').addEventListener('click', function () { modal.close(); });
    doneBtn.addEventListener('click', function () {
      modal.close();
      if (onDone) onDone();
    });
  }

  function checkEnd() {
    if (scrollArea.scrollTop + scrollArea.clientHeight < scrollArea.scrollHeight - 4) return;
    doneBtn.disabled = false;
    hint.textContent = '✓ You’ve reached the end of the notice';
    hint.classList.add('is-done');
  }

  function openNotice(lang, alreadyRead, callback) {
    if (!modal) buildModal();
    scrollArea.innerHTML = '<p class="dpn-scroll-title" lang="en" aria-hidden="true">Privacy Notice</p>' + noticeHTML(contentFor(lang).notice);
    scrollArea.lang = (lang === 'hi' && CONTENT.hi && CONTENT.hi.notice.length) ? 'hi' : 'en';
    onDone = callback;
    doneBtn.disabled = !alreadyRead;
    hint.textContent = alreadyRead ? '✓ You’ve reached the end of the notice' : 'Scroll to the end of the notice to continue';
    hint.classList.toggle('is-done', alreadyRead);
    modal.showModal();
    scrollArea.scrollTop = 0; // after showModal: scrollTop is ignored while the dialog is hidden
    checkEnd(); // short screens: notice may already fit
  }

  // If the text files can't be read (e.g. page opened straight from disk via file://, where browsers block fetch),
  // fall back to the English consent text already in the HTML and a short notice linking to the online policy.
  var FALLBACK_NOTICE = [
    'The full Privacy Notice could not be loaded here.',
    'Please read it at <a href="https://www.transunioncibil.com/legal/privacy-policy" target="_blank" rel="noopener">transunioncibil.com/legal/privacy-policy</a> before giving your consents.'
  ];
  function htmlFallback() {
    var out = { required: [], recommended: [], notice: FALLBACK_NOTICE };
    document.querySelectorAll('#dpConsent .dp-text').forEach(function (el) { out[el.dataset.src][+el.dataset.i] = el.innerHTML; });
    return out;
  }
  var ready = load('en')
    .catch(function () { CONTENT.en = htmlFallback(); })
    .then(function () { return load('hi').catch(function () {}); });

  /* ---------- Consent block ---------- */
  var card = document.getElementById('dpConsent');
  if (!card) return;

  // main.min.js may re-render the company form from its template; put the block back if it disappears.
  function ensureMounted() {
    if (document.body.contains(card)) return;
    var app = document.getElementById('appConsent');
    var btns = app && app.closest('.appli-actions').querySelector('.appli-action-btns');
    if (btns) btns.parentNode.insertBefore(card, btns);
  }

  var notice = card.querySelector('.dp-notice');
  var boxes = [].slice.call(card.querySelectorAll('.dp-item input'));
  var required = boxes.filter(function (b) { return b.hasAttribute('data-required'); });
  var langSel = card.querySelector('#dpLang');
  var lang = 'en', reviewed = false, nudgeTimer;

  function render() {
    var set = contentFor(lang);
    card.querySelectorAll('.dp-text').forEach(function (el) {
      el.innerHTML = set[el.dataset.src][+el.dataset.i] || el.innerHTML;
      el.lang = lang;
    });
  }

  // Drive the existing Submit button through the hidden #appConsent checkbox (main.min.js listens for "change").
  function syncSubmit() {
    var app = document.getElementById('appConsent');
    var ok = reviewed && required.every(function (b) { return b.checked; });
    var cont = document.getElementById('dpContinue'); // main-dashboard.html
    if (cont) cont.disabled = !ok;
    if (!app) return;
    if (app.checked !== ok) {
      app.checked = ok;
      app.dispatchEvent(new Event('change', { bubbles: true }));
    }
    fallbackSubmit();
  }

  // main.min.js only wires the Submit button when the URL ends in "addCompanyForm" (live site).
  // Elsewhere (e.g. this saved copy) nothing enables Submit, so do it here: required applicant
  // fields valid + #appConsent ticked. Same classes/attributes main.min.js toggles.
  function mainHandlesForm() {
    var form = document.querySelector('.fnCompanyForm');
    var ev = form && window.jQuery && window.jQuery._data && window.jQuery._data(form, 'events');
    return !!(ev && ev.change);
  }
  function fallbackSubmit() {
    if (mainHandlesForm()) return;
    var app = document.getElementById('appConsent');
    var step = app && app.closest('[data-company-step]');
    var btn = step && step.querySelector('[data-company-action]');
    if (!btn) return;
    var fields = [].slice.call(step.querySelectorAll('input[required], select[required]')).filter(function (el) { return el !== app; });
    var ok = app.checked && fields.every(function (el) { return el.value.trim() !== '' && el.checkValidity() && (el.type !== 'tel' || /^\d{10}$/.test(el.value.trim())); });
    btn.classList.toggle('btn-primary--muted', !ok);
    btn.disabled = !ok;
    btn.setAttribute('aria-disabled', String(!ok));
  }
  document.addEventListener('input', function (e) {
    if (e.target.closest && e.target.closest('[data-company-step]')) fallbackSubmit();
  });

  function clearNudge() {
    clearTimeout(nudgeTimer);
    notice.classList.remove('is-nudge');
    card.querySelectorAll('.dp-item.is-nudge').forEach(function (el) { el.classList.remove('is-nudge'); });
  }

  function markReviewed() {
    reviewed = true;
    card.classList.add('is-reviewed');
    boxes.forEach(function (b) { b.removeAttribute('aria-disabled'); });
    clearNudge();
    syncSubmit();
    card.querySelector('.dp-read-again').focus();
  }

  boxes.forEach(function (b) {
    b.addEventListener('click', function (e) {
      if (reviewed) return;
      e.preventDefault();
      clearNudge();
      void notice.offsetWidth; // restart the seesaw animation
      notice.classList.add('is-nudge');
      b.closest('.dp-item').classList.add('is-nudge');
      notice.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      nudgeTimer = setTimeout(clearNudge, 2000);
    });
    b.addEventListener('change', syncSubmit);
  });

  langSel.addEventListener('change', function () {
    lang = this.value;
    if (lang === 'hi') loadDevanagariFont();
    card.classList.toggle('is-hi', lang === 'hi');
    ready.then(render);
  });

  card.querySelector('.dp-read-btn').addEventListener('click', function () {
    ready.then(function () { openNotice(lang, false, markReviewed); });
  });
  card.querySelector('.dp-read-again').addEventListener('click', function () {
    ready.then(function () { openNotice(lang, true, markReviewed); });
  });

  ready.then(render).catch(function () {}); // HTML keeps the English text if the files can't load
  syncSubmit();
  document.addEventListener('DOMContentLoaded', function () { ensureMounted(); syncSubmit(); });
  window.addEventListener('load', function () { ensureMounted(); syncSubmit(); });
  // jQuery ready handlers (main.min.js) were registered first, so this runs after any re-render.
  if (window.jQuery) window.jQuery(function () { setTimeout(function () { ensureMounted(); syncSubmit(); }); });
})();
