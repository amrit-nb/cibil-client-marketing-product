/* manage-consent.html — behaviour ported from manage-consent/assets/js/main.js
 * (switch staging, sticky bar, Privacy Notice, withdraw confirm, toast, consent-text translations)
 * plus the company picker from Figma 34219-18202. */
(function () {
  var panel = document.querySelector('[data-consents]');
  if (!panel) return;

  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  // "12 Oct 2026, 10:42 AM"
  function stamp(d) {
    var h = d.getHours() % 12 || 12;
    var m = (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
    return d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear() + ', ' + h + ':' + m + ' ' + (d.getHours() < 12 ? 'AM' : 'PM');
  }

  var title = document.getElementById('consents-title');
  var bar = document.querySelector('[data-consent-bar]');
  var count = bar.querySelector('[data-consent-count]');
  var noun = bar.querySelector('[data-consent-noun]');
  var success = document.querySelector('[data-consent-success]');
  var switches = Array.prototype.slice.call(panel.querySelectorAll('[role="switch"]'));

  // Saved state = what the server has. Turning a non-granted consent ON only
  // stages it ("Unsaved") until the user gives consent via the Privacy Notice.
  switches.forEach(function (sw) { sw.dataset.saved = sw.dataset.saved || sw.getAttribute('aria-checked'); });

  function key(sw) { return sw.getAttribute('aria-labelledby'); }
  function statusEl(sw) { return document.getElementById(key(sw) + '-status'); }

  function setUnsaved(sw, unsaved) {
    var k = key(sw);
    var tag = document.getElementById(k + '-unsaved');
    sw.closest('.consent, .channel').classList.toggle('is-unsaved', unsaved);
    sw.classList.toggle('is-unsaved', unsaved);
    if (tag) tag.hidden = !unsaved;
    var ids = sw.getAttribute('aria-describedby').split(' ').filter(function (id) { return id !== k + '-unsaved'; });
    if (unsaved) ids.unshift(k + '-unsaved');
    sw.setAttribute('aria-describedby', ids.join(' '));
  }

  function updateBar() {
    var n = switches.filter(function (sw) { return sw.classList.contains('is-unsaved'); }).length;
    var visible = !bar.hidden && !bar.classList.contains('is-leaving');
    if (n && !visible) {
      bar.classList.remove('is-leaving');
      bar.hidden = false;
      bar.classList.add('is-entering');
    } else if (!n && visible) {
      bar.classList.remove('is-entering');
      bar.classList.add('is-leaving');
    }
    count.textContent = n;
    noun.textContent = n === 1 ? 'consent' : 'consents';
  }
  bar.addEventListener('animationend', function () {
    if (bar.classList.contains('is-leaving')) bar.hidden = true;
    bar.classList.remove('is-entering', 'is-leaving');
  });

  panel.addEventListener('click', function (e) {
    var sw = e.target.closest('[role="switch"]');
    if (!sw) return;
    var on = sw.getAttribute('aria-checked') !== 'true';
    if (sw.dataset.saved === 'true' && !on) { openWithdraw(sw); return; } // withdrawing needs confirmation
    sw.setAttribute('aria-checked', String(on));
    setUnsaved(sw, on);
    updateBar();
  });

  // ---------- Companies: each keeps its own consent state ----------
  // ponytail: state lives in memory per company; the backend would load it per company.
  var companies = Array.prototype.slice.call(document.querySelectorAll('[data-company]'));
  var nameEl = panel.querySelector('[data-company-name]');
  function snapshot() {
    return switches.map(function (sw) {
      return { on: sw.getAttribute('aria-checked'), saved: sw.dataset.saved, unsaved: sw.classList.contains('is-unsaved'), status: statusEl(sw).textContent };
    });
  }
  function restore(state) {
    switches.forEach(function (sw, i) {
      var s = state[i];
      sw.setAttribute('aria-checked', s.on);
      sw.dataset.saved = s.saved;
      statusEl(sw).textContent = s.status;
      setUnsaved(sw, s.unsaved);
    });
  }
  var initial = snapshot();
  var states = companies.map(function () { return initial; });
  var current = 0;
  function switchTo(i) {
    var btn = companies[i];
    states[current] = snapshot();
    companies[current].setAttribute('aria-pressed', 'false');
    btn.setAttribute('aria-pressed', 'true');
    current = i;
    restore(states[i]);
    nameEl.textContent = btn.textContent;
    bar.querySelector('[data-bar-company]').textContent = btn.textContent;
    success.hidden = true;
    updateBar();
  }

  // Unsaved changes (Figma 34219-18472): stay, or discard staged switches and move on.
  var un = document.getElementById('unsaved-notice');
  var pending = null;
  var unReturn = null;
  wireDialog(un, function () { if (unReturn) unReturn.focus(); });
  un.querySelector('[data-unsaved-stay]').addEventListener('click', function () {
    unReturn = companies[current];
    close(un);
  });
  un.querySelector('[data-unsaved-discard]').addEventListener('click', function () {
    switches.forEach(function (sw) {
      if (!sw.classList.contains('is-unsaved')) return;
      sw.setAttribute('aria-checked', sw.dataset.saved);
      setUnsaved(sw, false);
    });
    switchTo(pending);
    unReturn = companies[pending];
    close(un);
  });

  companies.forEach(function (btn, i) {
    btn.addEventListener('click', function () {
      if (i === current) return;
      if (switches.some(function (sw) { return sw.classList.contains('is-unsaved'); })) {
        pending = i;
        unReturn = btn; // Esc / backdrop close returns focus here
        un.querySelector('[data-unsaved-company]').textContent = companies[current].textContent;
        open(un);
        un.querySelector('[data-unsaved-stay]').focus();
        return;
      }
      switchTo(i);
    });
  });

  // ---------- Toast (mobile only; CSS hides it on desktop) ----------
  var toast = document.querySelector('[data-consent-toast]');
  var toastTimer;
  function showToast(text) {
    clearTimeout(toastTimer);
    toast.querySelector('[data-consent-toast-title]').textContent = text;
    toast.classList.remove('is-leaving');
    toast.hidden = false;
    toast.classList.add('is-entering');
    toastTimer = setTimeout(function () {
      toast.classList.remove('is-entering');
      toast.classList.add('is-leaving');
      toastTimer = setTimeout(function () { toast.classList.remove('is-leaving'); toast.hidden = true; }, 250);
    }, 4000);
  }

  // ---------- Dialog helpers (open/close with CSS animation) ----------
  function wireDialog(dlg, onClosed) {
    dlg.addEventListener('animationend', function (e) {
      if (e.target !== dlg) return;
      if (dlg.classList.contains('is-closing')) {
        dlg.classList.remove('is-closing');
        dlg.close();
        onClosed();
      } else {
        dlg.classList.remove('is-opening');
      }
    });
    dlg.addEventListener('cancel', function (e) { e.preventDefault(); close(dlg); });
    dlg.addEventListener('click', function (e) {
      if (e.target !== dlg) return;
      var r = dlg.getBoundingClientRect();
      if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) close(dlg);
    });
  }
  function open(dlg) { dlg.classList.remove('is-closing'); dlg.showModal(); dlg.classList.add('is-opening'); }
  function close(dlg) {
    if (!dlg.open || dlg.classList.contains('is-closing')) return;
    dlg.classList.remove('is-opening');
    dlg.classList.add('is-closing');
  }

  // ---------- Privacy Notice: opened from the sticky bar; DONE saves staged consents ----------
  var notice = document.getElementById('privacy-notice');
  var giveBtn = bar.querySelector('[data-give-consent]');
  var scrollBox = notice.querySelector('[data-notice-scroll]');
  var doneBtn = notice.querySelector('[data-notice-done]');
  var hint = notice.querySelector('.notice__hint');

  function checkRead() {
    if (scrollBox.scrollTop + scrollBox.clientHeight >= scrollBox.scrollHeight - 4) {
      doneBtn.disabled = false;
      hint.innerHTML = '<span aria-hidden="true">✓ </span>You\'ve reached the end of the notice';
      hint.classList.add('is-done');
    }
  }
  giveBtn.addEventListener('click', function () {
    doneBtn.disabled = true;
    hint.textContent = 'Scroll to the end of the notice to continue';
    hint.classList.remove('is-done');
    open(notice);
    scrollBox.scrollTop = 0; // only works once rendered
    checkRead();
  });
  scrollBox.addEventListener('scroll', checkRead);
  notice.querySelector('[data-notice-close]').addEventListener('click', function () { close(notice); });
  wireDialog(notice, function () {
    if (!bar.hidden && !bar.classList.contains('is-leaving')) giveBtn.focus();
    else title.focus({ preventScroll: true });
  });

  // Partial-failure banner (error1.html)
  var alertBox = document.querySelector('[data-consent-alert]');
  if (alertBox) alertBox.querySelector('[data-consent-alert-close]').addEventListener('click', function () {
    alertBox.hidden = true;
    title.focus();
  });

  success.querySelector('[data-consent-success-close]').addEventListener('click', function () {
    success.hidden = true;
    title.focus();
  });

  doneBtn.addEventListener('click', function () {
    var now = stamp(new Date());
    var n = 0;
    switches.forEach(function (sw) {
      if (!sw.classList.contains('is-unsaved')) return;
      n++;
      setUnsaved(sw, false);
      sw.dataset.saved = 'true';
      statusEl(sw).textContent = 'Consent granted on ' + now;
    });
    var msg = n + ' of ' + n + ' consent' + (n === 1 ? '' : 's') + ' granted';
    success.querySelector('[data-consent-success-title]').textContent = msg;
    success.querySelector('[data-consent-success-sub]').textContent = 'Your consent preferences are saved. Last updated on ' + now + '.';
    success.hidden = false;
    if (alertBox) alertBox.hidden = true;
    showToast(msg);
    updateBar();
    close(notice);
  });

  // ---------- Withdraw confirmation ----------
  var wd = document.getElementById('withdraw-notice');
  var wdSwitch = null;
  function openWithdraw(sw) {
    wdSwitch = sw;
    wd.querySelector('[data-withdraw-name]').textContent = document.getElementById(key(sw)).textContent.trim();
    wd.querySelector('[data-withdraw-company]').textContent = companies[current].textContent;
    open(wd);
    wd.querySelector('[data-withdraw-keep]').focus();
  }
  wireDialog(wd, function () { if (wdSwitch) wdSwitch.focus(); });
  // error2.html: "Try Again" reopens the withdraw notice for the consent that failed
  var retry = document.querySelector('[data-withdraw-retry]');
  if (retry) retry.addEventListener('click', function () {
    openWithdraw(panel.querySelector('[aria-labelledby="' + retry.dataset.withdrawRetry + '"]'));
  });
  wd.querySelector('[data-withdraw-keep]').addEventListener('click', function () { close(wd); });
  wd.querySelector('[data-withdraw-confirm]').addEventListener('click', function () {
    wdSwitch.setAttribute('aria-checked', 'false');
    wdSwitch.dataset.saved = 'false';
    statusEl(wdSwitch).textContent = 'Consent withdrawn on ' + stamp(new Date());
    if (alertBox) alertBox.hidden = true;
    close(wd);
  });
})();

// Mobile company selector + "Select a company" sheet (Figma 34442-1215 / 34442-1309).
// Picking an option clicks the matching desktop company button, so the unsaved-changes
// check and per-company state run unchanged. The selector and ticks follow aria-pressed.
(function () {
  var sheet = document.getElementById('company-sheet');
  var trigger = document.querySelector('[data-company-selector]');
  if (!sheet || !trigger) return;
  var opts = Array.prototype.slice.call(sheet.querySelectorAll('[data-sheet-opt]'));
  var companies = Array.prototype.slice.call(document.querySelectorAll('[data-company]'));
  var nameEl = trigger.querySelector('[data-selector-name]');
  var hasPanel = !!document.querySelector('[data-consents]');

  function sync() {
    companies.forEach(function (c, i) {
      var on = c.getAttribute('aria-pressed') === 'true';
      opts[i].setAttribute('aria-pressed', String(on));
      if (on) nameEl.textContent = c.textContent;
    });
  }
  new MutationObserver(sync).observe(document.querySelector('.mc-companies'), { attributes: true, subtree: true, attributeFilter: ['aria-pressed'] });

  trigger.addEventListener('click', function () { sheet.showModal(); });
  sheet.querySelector('[data-sheet-close]').addEventListener('click', function () { sheet.close(); });
  sheet.addEventListener('click', function (e) { // backdrop only, not the sheet's own padding
    if (e.target !== sheet) return;
    var r = sheet.getBoundingClientRect();
    if (e.clientY < r.top) sheet.close();
  });
  opts.forEach(function (opt, i) {
    opt.addEventListener('click', function () {
      sheet.close();
      if (hasPanel) { companies[i].click(); return; }
      // error3.html has no consent panel: just move the selection.
      companies.forEach(function (c, k) { c.setAttribute('aria-pressed', String(k === i)); });
    });
  });
})();

// Consent text translations: only the consent descriptions switch language.
// Text lives in files/dpdpa/content/manage-consent.txt ([lang] sections of  key = text  lines).
(function () {
  var select = document.querySelector('[data-lang]');
  var els = document.querySelectorAll('[data-i18n]');
  if (!select || !els.length || !window.fetch) return;
  var texts = {};
  var english = {};
  els.forEach(function (el) { english[el.dataset.i18n] = el.textContent; });

  function parse(txt) {
    var out = {}, cur = null;
    txt.split(/\r?\n/).forEach(function (line) {
      line = line.trim();
      if (!line || line[0] === '#') return;
      var sec = line.match(/^\[(\w+)\]$/);
      if (sec) { cur = out[sec[1]] = {}; return; }
      var eq = line.indexOf('=');
      if (cur && eq > 0) cur[line.slice(0, eq).trim()] = line.slice(eq + 1).trim();
    });
    return out;
  }
  function apply() {
    var lang = select.value;
    var t = texts[lang] || {};
    els.forEach(function (el) {
      var k = el.dataset.i18n;
      el.textContent = t[k] || english[k]; // missing translation stays English
      if (t[k] && lang !== 'en') el.lang = lang; else el.removeAttribute('lang');
    });
  }

  // ponytail: HTML keeps the English text as a fallback if the file can't be loaded (e.g. file://).
  fetch('files/dpdpa/content/manage-consent.txt', { cache: 'no-cache' })
    .then(function (r) { return r.ok ? r.text() : Promise.reject(r.status); })
    .then(function (txt) { texts = parse(txt); apply(); })
    .catch(function () {});

  select.addEventListener('change', apply);
})();
