$(document).ready(function () {
  $(".language-selector").click(function (e) {
    $(".language-selector, .language-list").toggleClass("active");
    $(".language-list").toggle("medium");
    if ($(".hamburger").hasClass("opened")) {
      $(".hamburger, .mobile-nav-list").removeClass("opened");
      $(".mobile-nav-list").hide("medium");
      $(".overlay").addClass("opened");
    } else {
      $(".overlay").toggleClass("opened");
    }
  });
  $(document).click(function () {
    $(".language-list").hide("medium");
    $(".overlay").removeClass("opened");
    $(".mobile-nav-list").hide("medium").removeClass("opened");
    $(".hamburger").removeClass("opened");
  });
  $(".language-list, .language-selector, .hamburger, .overview-toggle").click(function (e) {
    e.stopPropagation();
  });
  $(".language-list .langauge-item").click(function (e) {
    $(".language-list").toggle("medium");
  });
  $(".langauge-item").click(function () {
    $(this).siblings().removeClass("active");
    $(this).addClass("active");
    $(".language-selector span").text($(this).text());
    setTimeout(function () {
      $(".language-selector, .language-list").removeClass("active");
      $(".language-list").hide("medium");
      $(".overlay").removeClass("opened");
    }, 100);
  });

});



$("#otpBtn").click(function () {
  $(this).addClass('disabled')
  $(this).html("Resend OTP <span id='count'></span>")

  $('.otp-wrapper input').removeAttr('disabled')

  function formatTime(seconds) {
    var m = Math.floor(seconds / 60) % 60,
      s = seconds % 60;
    if (m < 10) m = "0" + m;
    if (s < 10) s = "0" + s;
    return m + ":" + s;
  }
  var count = 30;
  var counter = setInterval(timer, 1000);

  function timer() {
    count--;
    if (count <= 0) {
      clearInterval(counter)
      $("#otpBtn").html("Resend")
      $("#otpBtn").removeClass('disabled')
    }
    document.getElementById('count').innerHTML = formatTime(count);
  }
  $("#emailOTP").removeAttr("disabled");
});

//otp input js
const $inp = $(".otp-input");

function checkOTPFilled() {
  const allFilled = $inp.toArray().every(input => input.value !== '');
  if (allFilled) showSnackbar();
}

function showSnackbar() {
  const sb = $("#snackbar");
  sb.addClass("show");
  setTimeout(() => sb.removeClass("show"), 3000);
}

$inp.on({
  paste(ev) {
    const clip = ev.originalEvent.clipboardData.getData('text').trim();
    if (!/^\d{6}$/.test(clip)) return ev.preventDefault();
    const s = [...clip];
    $inp.val((i) => s[i]).eq(5).focus();
    setTimeout(checkOTPFilled, 10); // allow paste to finish
  },
  input(ev) {
    const i = $inp.index(this);
    if (this.value) $inp.eq(i + 1).focus();
    checkOTPFilled();
  },
  keydown(ev) {
    const i = $inp.index(this);
    if (!this.value && ev.key === "Backspace" && i) $inp.eq(i - 1).focus();
  }
});

//change the CTA
var applyBtn = document.querySelector('.apply-btn');
if (applyBtn) {
  applyBtn.addEventListener('click', function(e) {
    e.preventDefault();
    this.textContent = this.textContent === 'Apply' ? 'Remove' : 'Apply';
  });
}

//password validation
const passwordInput = document.querySelector('#password');
if (passwordInput) {
  const validLength = document.querySelector('#validLength');
  const validUppercase = document.querySelector('#validUppercase');
  const validLowercase = document.querySelector('#validLowercase');
  const validNumber = document.querySelector('#validNumber');
  const validSpecial = document.querySelector('#validSpecial');
  const validSpaces = document.querySelector('#validSpaces');

  const validationCriteria = {
    validLength: false, validUppercase: false, validLowercase: false,
    validSpecial: false, validSpaces: false, validNumber: false,
  };

  const updateUI = () => {
    validLength.classList = validationCriteria.validLength ? "valid" : "invalid";
    validUppercase.classList = validationCriteria.validUppercase ? "valid" : "invalid";
    validLowercase.classList = validationCriteria.validLowercase ? "valid" : "invalid";
    validSpecial.classList = validationCriteria.validSpecial ? "valid" : "invalid";
    validSpaces.classList = validationCriteria.validSpaces ? "valid" : "invalid";
    validNumber.classList = validationCriteria.validNumber ? "valid" : "invalid";
  };

  passwordInput.addEventListener("input", (e) => {
    const p = e.target.value;
    validationCriteria.validLength = p.length >= 12;
    validationCriteria.validUppercase = /[A-Z]/.test(p);
    validationCriteria.validLowercase = /[a-z]/.test(p);
    validationCriteria.validSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(p);
    validationCriteria.validSpaces = !/\s/.test(p);
    validationCriteria.validNumber = /\d/.test(p);
    updateUI();
  });
}

//password show hide
function togglePassword(fieldId, iconWrapper) {
  const input = document.getElementById(fieldId);
  const isVisible = input.type === "text";

  input.type = isVisible ? "password" : "text";

  iconWrapper.innerHTML = isVisible
      ? `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
<mask id="mask0_1175_15288" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24">
<rect width="24" height="24" fill="#D9D9D9"/>
</mask>
<g mask="url(#mask0_1175_15288)">
<path d="M12.0028 15.5769C13.1359 15.5769 14.0983 15.1803 14.89 14.3871C15.6816 13.5939 16.0775 12.6308 16.0775 11.4977C16.0775 10.3646 15.6809 9.40224 14.8877 8.61058C14.0945 7.81891 13.1314 7.42308 11.9983 7.42308C10.8652 7.42308 9.90283 7.81966 9.11116 8.61282C8.3195 9.40601 7.92366 10.3692 7.92366 11.5023C7.92366 12.6353 8.32025 13.5977 9.11341 14.3894C9.9066 15.181 10.8697 15.5769 12.0028 15.5769ZM12.0006 14.2C11.2506 14.2 10.6131 13.9375 10.0881 13.4125C9.56306 12.8875 9.30056 12.25 9.30056 11.5C9.30056 10.75 9.56306 10.1125 10.0881 9.58747C10.6131 9.06247 11.2506 8.79997 12.0006 8.79997C12.7506 8.79997 13.3881 9.06247 13.9131 9.58747C14.4381 10.1125 14.7006 10.75 14.7006 11.5C14.7006 12.25 14.4381 12.8875 13.9131 13.4125C13.3881 13.9375 12.7506 14.2 12.0006 14.2ZM12.0019 18.5C9.70232 18.5 7.607 17.8657 5.71596 16.5971C3.82495 15.3285 2.43265 13.6295 1.53906 11.5C2.43265 9.37049 3.8245 7.67146 5.71461 6.40287C7.60471 5.13429 9.69957 4.5 11.9992 4.5C14.2988 4.5 16.3941 5.13429 18.2852 6.40287C20.1762 7.67146 21.5685 9.37049 22.4621 11.5C21.5685 13.6295 20.1766 15.3285 18.2865 16.5971C16.3964 17.8657 14.3016 18.5 12.0019 18.5ZM12.0006 17C13.8839 17 15.6131 16.5041 17.1881 15.5125C18.7631 14.5208 19.9672 13.1833 20.8006 11.5C19.9672 9.81664 18.7631 8.47914 17.1881 7.48747C15.6131 6.49581 13.8839 5.99997 12.0006 5.99997C10.1172 5.99997 8.38806 6.49581 6.81306 7.48747C5.23806 8.47914 4.0339 9.81664 3.20056 11.5C4.0339 13.1833 5.23806 14.5208 6.81306 15.5125C8.38806 16.5041 10.1172 17 12.0006 17Z" fill="#262626"/>
</g>
</svg>`
      : `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
<mask id="mask0_1175_39183" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24">
<rect width="24" height="24" fill="#D9D9D9"/>
</mask>
<g mask="url(#mask0_1175_39183)">
<path d="M15.7736 12.973L14.6506 11.8499C14.8006 11.0217 14.5643 10.2772 13.9419 9.61627C13.3195 8.95537 12.5557 8.69992 11.6506 8.84992L10.5275 7.72687C10.7531 7.62559 10.9846 7.54963 11.2217 7.499C11.4589 7.44835 11.7185 7.42302 12.0006 7.42302C13.1352 7.42302 14.0983 7.81885 14.89 8.61052C15.6816 9.40219 16.0775 10.3653 16.0775 11.4999C16.0775 11.782 16.0521 12.0448 16.0015 12.2884C15.9509 12.532 15.8749 12.7602 15.7736 12.973ZM18.9544 16.0845L17.8506 15.0499C18.4839 14.5666 19.0464 14.0374 19.5381 13.4624C20.0297 12.8874 20.4506 12.2333 20.8006 11.4999C19.9672 9.81659 18.7714 8.47909 17.2131 7.48742C15.6547 6.49575 13.9172 5.99992 12.0006 5.99992C11.5172 5.99992 11.0422 6.03325 10.5756 6.09992C10.1089 6.16659 9.65056 6.26659 9.20056 6.39992L8.03521 5.23457C8.66726 4.98329 9.31277 4.79803 9.97174 4.6788C10.6307 4.55956 11.307 4.49995 12.0006 4.49995C14.3441 4.49995 16.4576 5.1461 18.3409 6.4384C20.2242 7.73071 21.598 9.41789 22.4621 11.4999C22.0915 12.3935 21.613 13.2275 21.0265 14.0018C20.44 14.7762 19.7493 15.4704 18.9544 16.0845ZM19.7621 21.8691L15.716 17.8537C15.2031 18.0435 14.6349 18.1986 14.0112 18.3191C13.3874 18.4396 12.7172 18.4999 12.0006 18.4999C9.65058 18.4999 7.53713 17.8537 5.66021 16.5614C3.7833 15.2691 2.40958 13.582 1.53906 11.4999C1.9083 10.6166 2.38522 9.79255 2.96984 9.0278C3.55445 8.26306 4.19805 7.59993 4.90061 7.0384L2.13136 4.2384L3.18521 3.18457L20.8159 20.8153L19.7621 21.8691ZM5.95444 8.0922C5.42624 8.51271 4.91245 9.01817 4.41309 9.60857C3.91372 10.199 3.50955 10.8294 3.20056 11.4999C4.0339 13.1833 5.22973 14.5208 6.78806 15.5124C8.3464 16.5041 10.0839 16.9999 12.0006 16.9999C12.4557 16.9999 12.9089 16.9615 13.3602 16.8845C13.8115 16.8076 14.1942 16.7281 14.5083 16.6461L13.2429 15.3499C13.0724 15.4191 12.8749 15.4742 12.6506 15.5153C12.4262 15.5563 12.2095 15.5768 12.0006 15.5768C10.866 15.5768 9.90283 15.181 9.11116 14.3893C8.3195 13.5977 7.92366 12.6345 7.92366 11.4999C7.92366 11.2974 7.94418 11.0855 7.98521 10.8643C8.02625 10.6432 8.08137 10.4409 8.15059 10.2576L5.95444 8.0922Z" fill="#262626"/>
</g>
</svg>`;
}

// accordion
$(document).ready(function () {
  $('.accordion-header').click(function () {
      const $accordionItem = $(this).parent();
      const $content = $accordionItem.find('.accordion-content');
      const $parentSection = $(this).closest('.form-group');

      // If this item is already active, close it smoothly
      if ($accordionItem.hasClass('active')) {
          $content.slideUp(300, function () {
              $accordionItem.removeClass('active');
          });
      } else {
          // Close other accordion items within the same section smoothly
          $parentSection.find('.accordion-item.active .accordion-content').slideUp(300, function () {
              $parentSection.find('.accordion-item.active').removeClass('active');
          });

          // Open clicked item smoothly
          $accordionItem.addClass('active');
          $content.slideDown(300);
      }
  });
});

// dropdown
document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
  const selected = dropdown.querySelector('.dropdown-selected');
  const options = dropdown.querySelectorAll('.dropdown-option');

  selected.addEventListener('click', () => {
      dropdown.classList.toggle('active');
  });

  options.forEach(option => {
      option.addEventListener('click', () => {
          selected.textContent = option.textContent;
          dropdown.classList.remove('active');
          var grp = dropdown.closest('.form-group');
          if (grp) grp.classList.remove('error');
      });
  });

  // Optional: close dropdown on outside click
  document.addEventListener('click', e => {
      if (!dropdown.contains(e.target)) {
          dropdown.classList.remove('active');
      }
  });
});

//form stepper
let currentStep = 0;
const formSteps = document.querySelectorAll(".form-step");
const steppers = document.querySelectorAll(".main-stepper ul li");
const mobileSteppers = document.querySelectorAll(".mobile-progress-item");
const faqAccordion = document.querySelectorAll('.main-left .faq-accordion');

function showStep(stepIndex) {
  // Update form step visibility
  formSteps.forEach((stepEl, index) => {
    stepEl.classList.toggle("active", index === stepIndex);
  });

  // Clear all stepper states
  steppers.forEach(step => step.classList.remove("active", "completed"));
  mobileSteppers.forEach(step => step.classList.remove("active", "completed"));

  // Apply new stepper logic
  if (stepIndex === 0) {
    steppers[0].classList.add("active");
    mobileSteppers[0].classList.add("active");
    if (faqAccordion[0]) faqAccordion[0].classList.remove('show');
  }
  if (stepIndex === 1) {
    steppers[0].classList.add("completed");
    mobileSteppers[0].classList.add("completed");
    steppers[1].classList.add("active");
    mobileSteppers[1].classList.add("active");
    if (faqAccordion[0]) faqAccordion[0].classList.add('show');
  }
  if (stepIndex === 2) {
    steppers[0].classList.add("completed");
    mobileSteppers[0].classList.add("completed");
    steppers[1].classList.add("completed");
    mobileSteppers[1].classList.add("completed");
    steppers[2].classList.add("active");
    mobileSteppers[2].classList.add("active");
    if (faqAccordion[0]) faqAccordion[0].classList.remove('show');
    populateReviewStep();
  }
  if (stepIndex === 3) {
    steppers[0].classList.add("completed");
    mobileSteppers[0].classList.add("completed");
    steppers[1].classList.add("completed");
    mobileSteppers[1].classList.add("completed");
    steppers[2].classList.add("completed");
    mobileSteppers[2].classList.add("completed");
    if (faqAccordion[0]) faqAccordion[0].classList.remove('show');
  }
  // Disable back button on first step
  const backLink = document.getElementById("mobileBack");
  if (stepIndex > 0) {
    backLink.classList.remove("hide");
  } else {
    backLink.classList.add("hide");
  }
}


function validateStep(stepIndex) {
  const step = formSteps[stepIndex];
  let valid = true;

  // validate text/password inputs (skip readonly)
  step.querySelectorAll('input[type="text"], input[type="password"]').forEach(input => {
    if (input.readOnly) return;
    const group = input.closest('.form-group');
    if (!group) return;
    if (!input.value.trim()) {
      group.classList.add('error');
      valid = false;
    } else {
      group.classList.remove('error');
    }
  });

  // validate custom dropdowns (skip ones showing a real selection)
  step.querySelectorAll('.custom-dropdown').forEach(dd => {
    const selected = dd.querySelector('.dropdown-selected');
    const group = dd.closest('.form-group');
    if (!group || !selected) return;
    const placeholders = ['Select Option', 'Select an option', 'Select State'];
    if (placeholders.includes(selected.textContent.trim())) {
      group.classList.add('error');
      valid = false;
    } else {
      group.classList.remove('error');
    }
  });

  return valid;
}

function nextStep() {
  if (!validateStep(currentStep)) return;
  if (currentStep < formSteps.length - 1) {
    currentStep++;
    showStep(currentStep);
  }
}

function prevStep() {
  if (currentStep > 0) {
    currentStep--;
    showStep(currentStep);
  }
}

// document.getElementById("multiStepForm").addEventListener("submit", function (e) {
//   e.preventDefault();
//   alert("Form submitted!");
// });

showStep(currentStep);