/* ── State ── */
let currentPlanKey = 'premium';
let currentActiveTab = 'combo';
const duoState = {};

/* ── Plan ordering (high → low tier) ── */
const IND_ORDER = ['premium', 'standard', 'basic', 'starter'];
const CMB_ORDER = ['combo-premium', 'combo-standard', 'combo-basic'];

/* ── Config for "other plans" per selected plan ── */
const OTHER_PLANS = {
  'premium':        { noTabs: true,  showPlans: ['combo-premium','combo-standard','combo-basic'], comboBand: true  },
  'standard':       { noTabs: false, activeTab: 'individual', comboBand: false },
  'basic':          { noTabs: false, activeTab: 'individual', comboBand: false },
  'starter':        { noTabs: false, activeTab: 'individual', comboBand: false },
  'combo-premium':  { noTabs: true,  showPlans: ['premium'],  comboBand: false },
  'combo-standard': { noTabs: false, activeTab: 'combo',      comboBand: false },
  'combo-basic':    { noTabs: false, activeTab: 'combo',      comboBand: false },
};

/* ── DOM helpers ── */
function getAllOtherRows() {
  return [...document.querySelectorAll('#puOtherPlans .pu-plan-row')];
}
function getSelectedRow() {
  return document.querySelector('#puPlans .pu-plan-row.is-selected');
}

/* ── Determine which rows show for a given tab ── */
function visibleKeysForTab(tab, selectedKey) {
  const selectedTab = getSelectedRow() ? getSelectedRow().dataset.tab : 'individual';

  if (tab === 'individual') {
    if (selectedTab === 'individual') {
      // Show individual plans ABOVE the selected one only
      const idx = IND_ORDER.indexOf(selectedKey);
      return IND_ORDER.slice(0, idx);
    }
    // Combo plan selected → show ALL individual plans
    return IND_ORDER.slice();
  } else {
    // tab === 'combo'
    if (selectedTab === 'combo') {
      // Show combo plans ABOVE the selected one only
      const idx = CMB_ORDER.indexOf(selectedKey);
      return CMB_ORDER.slice(0, idx);
    }
    // Individual plan selected → show ALL combo plans
    return CMB_ORDER.slice();
  }
}

/* ── Show rows for tab (tab-switch mode) ── */
function showRowsForTab(tab, selectedKey) {
  const visible = visibleKeysForTab(tab, selectedKey);
  getAllOtherRows().forEach(r => {
    const shouldShow = r.dataset.tab === tab && visible.includes(r.dataset.planKey);
    r.classList.toggle('hidden', !shouldShow);
  });
}

/* ── Update "other plans" display after a plan is selected ── */
function updateOtherPlansDisplay(planKey) {
  const config = OTHER_PLANS[planKey];
  const tabsEl = document.getElementById('puPlanTabs');
  const bandEl = document.getElementById('puComboBand');
  const allRows = getAllOtherRows();

  if (config.noTabs) {
    tabsEl.classList.add('hidden');
    allRows.forEach(r => {
      r.classList.toggle('hidden', !config.showPlans.includes(r.dataset.planKey));
    });
    // Combo band: show only when premium (individual) shows combo plans
    bandEl.classList.toggle('hidden', !config.comboBand);
    currentActiveTab = config.comboBand ? 'combo' : 'individual';
  } else {
    tabsEl.classList.remove('hidden');
    currentActiveTab = config.activeTab;
    // Sync tab button active states
    tabsEl.querySelectorAll('.pu-plan-toggle-btn').forEach(btn => {
      btn.classList.toggle('is-active', btn.dataset.planTab === config.activeTab);
    });
    showRowsForTab(config.activeTab, planKey);
    bandEl.classList.add('hidden');
  }
}

/* ── Switch tab in "other plans" ── */
function switchOtherTab(btn, tab) {
  currentActiveTab = tab;
  document.querySelectorAll('#puPlanTabs .pu-plan-toggle-btn').forEach(b => {
    b.classList.toggle('is-active', b === btn);
  });
  showRowsForTab(tab, currentPlanKey);

  // Combo band: show only when combo tab active AND individual plan selected
  const selectedRow = getSelectedRow();
  const isIndividual = selectedRow && selectedRow.dataset.tab === 'individual';
  document.getElementById('puComboBand').classList.toggle('hidden', !(tab === 'combo' && isIndividual));
}

/* ── Return a plan row to #puOtherPlans in original order ── */
function insertRowInOrder(row) {
  const puOtherPlans = document.getElementById('puOtherPlans');
  const isCombo = row.dataset.tab === 'combo';
  const ORDER = isCombo ? CMB_ORDER : IND_ORDER;
  const rowIdx = ORDER.indexOf(row.dataset.planKey);
  const allRows = [...puOtherPlans.querySelectorAll('.pu-plan-row')];
  const comboBand = document.getElementById('puComboBand');

  // Find first same-tab row with higher index (goes later in list)
  let refNode = comboBand;
  for (const r of allRows) {
    if (r.dataset.tab !== row.dataset.tab) continue;
    if (ORDER.indexOf(r.dataset.planKey) > rowIdx) { refNode = r; break; }
  }
  // Individual rows go before combo rows
  if (!isCombo && refNode === comboBand) {
    const firstCombo = allRows.find(r => r.dataset.tab === 'combo');
    if (firstCombo) refNode = firstCombo;
  }
  puOtherPlans.insertBefore(row, refNode);
}

/* ── Select a plan ── */
function selectPlan(row) {
  const prevSelected = getSelectedRow();
  if (prevSelected === row) return;

  const planKey = row.dataset.planKey;
  currentPlanKey = planKey;

  // Deselect and move previous to #puOtherPlans in original order
  if (prevSelected) {
    prevSelected.classList.remove('is-selected');
    if (document.getElementById('puPlans').contains(prevSelected)) {
      insertRowInOrder(prevSelected);
    }
  }

  // Move new selection to #puPlans before the toggle
  row.classList.add('is-selected');
  row.classList.remove('hidden');
  document.getElementById('puPlans').insertBefore(row, document.getElementById('puHideToggle'));

  // Restore Duo checkbox state
  const duoCheck = row.querySelector('.pu-duo-check');
  if (duoCheck) {
    duoCheck.checked = !!duoState[planKey];
    syncDuoLabel(row);
  }

  updateOtherPlansDisplay(planKey);
  updateFeatures(row.dataset.featKey);
  updateSummary();
}

/* ── Toggle show/hide other plans ── */
function toggleOtherPlans() {
  const otherEl = document.getElementById('puOtherPlans');
  const isCollapsed = otherEl.classList.toggle('pu-collapsed');
  document.getElementById('puHideLabel').textContent = isCollapsed ? 'Show other plans' : 'Hide other plans';
  document.getElementById('puHideChevron').classList.toggle('is-collapsed', isCollapsed);
}

/* ── Duo checkbox ── */
function toggleDuo(e, labelEl) {
  e.stopPropagation();
  const row = labelEl.closest('.pu-plan-row');
  const checkbox = labelEl.querySelector('.pu-duo-check');
  const planKey = row.dataset.planKey;

  checkbox.checked = !checkbox.checked;
  duoState[planKey] = checkbox.checked;
  syncDuoLabel(row);

  if (row.classList.contains('is-selected')) {
    updateSummary();
  }
}

function syncDuoLabel(row) {
  const addonRow = row.querySelector('.pu-addon-row');
  if (!addonRow) return;
  addonRow.classList.toggle('is-checked', !!row.querySelector('.pu-duo-check').checked);
}

/* ── Update price summary ── */
function updateSummary() {
  const row = getSelectedRow();
  if (!row) return;

  const planKey = row.dataset.planKey;
  const isDuo = !!duoState[planKey] && !!row.dataset.duoName;
  const isOneTime = row.dataset.oneTime === 'true';

  const name     = isDuo ? row.dataset.duoName     : row.dataset.name;
  const price    = parseInt(isDuo ? row.dataset.duoPrice : row.dataset.price, 10);
  const duration = isDuo ? row.dataset.duoDuration : row.dataset.duration;

  document.getElementById('puSummaryName').textContent     = name;
  document.getElementById('puSummaryPrice').textContent    = '₹' + price.toLocaleString('en-IN');
  document.getElementById('puSummaryDuration').textContent = duration;
  document.getElementById('puTotalAmount').textContent     = '₹' + price.toLocaleString('en-IN');

  // Hide discount section for Starter (one-time purchase)
  document.getElementById('puCodeSection').style.display = isOneTime ? 'none' : '';
}

/* ── Update features section ── */
function updateFeatures(featKey) {
  document.querySelectorAll('.pu-feat-section').forEach(el => {
    el.style.display = el.dataset.feat === featKey ? '' : 'none';
  });
}

/* ── Code tabs (Discount / Referral) ── */
function switchCodeTab(btn, tab) {
  document.querySelectorAll('.pu-code-tab').forEach(b => b.classList.toggle('is-active', b === btn));
  document.getElementById('puCodeLabel').textContent = tab === 'discount' ? 'Enter Discount Code' : 'Enter Referral Code';
  document.getElementById('puCodeInput').value = '';
  const msg = document.getElementById('puCodeMsg');
  msg.textContent = '';
  msg.classList.add('hidden');
  msg.classList.remove('is-success', 'is-error');
}

/* ── Apply code ── */
const VALID_CODES = ['CIBIL100', 'SAVE10'];

function applyCode() {
  const input = document.getElementById('puCodeInput');
  const msg   = document.getElementById('puCodeMsg');
  const code  = input.value.trim().toUpperCase();

  msg.classList.remove('hidden', 'is-success', 'is-error');

  if (!code) {
    msg.classList.add('is-error');
    msg.textContent = 'Please enter a code.';
    return;
  }

  if (VALID_CODES.includes(code)) {
    msg.classList.add('is-success');
    msg.textContent = 'Code applied successfully!';
  } else {
    msg.classList.add('is-error');
    msg.textContent = 'Invalid code. Please try again.';
  }
}

/* ── Click delegation ── */
document.getElementById('puPlans').addEventListener('click', function(e) {
  if (e.target.closest('.pu-addon-row')) return;
  const row = e.target.closest('.pu-plan-row');
  if (row) selectPlan(row);
});

document.getElementById('puOtherPlans').addEventListener('click', function(e) {
  if (e.target.closest('.pu-addon-row')) return;
  const row = e.target.closest('.pu-plan-row');
  if (row) selectPlan(row);
});

/* ── Init ── */
(function init() {
  updateOtherPlansDisplay('premium');
  updateFeatures('std-prem');
  updateSummary();
})();
