const puPlansEl = document.getElementById('puPlans');
const puOtherEl = document.getElementById('puOtherPlans');
let puActiveTab = 'individual';
const duoState = {};

const PLAN_ORDER = {
  individual: ['premium', 'standard', 'basic', 'starter'],
  combo: ['premium', 'standard', 'basic']
};

function getAllRows() {
  return [...puPlansEl.querySelectorAll('.pu-plan-row'), ...puOtherEl.querySelectorAll('.pu-plan-row')];
}

function getFirstPlanForTab(tab) {
  return PLAN_ORDER[tab][0];
}

function insertRowInOrder(row) {
  const order = PLAN_ORDER[row.dataset.tab] || [];
  const rowIndex = order.indexOf(row.dataset.plan);
  const existing = [...puOtherEl.querySelectorAll(`.pu-plan-row[data-tab="${row.dataset.tab}"]`)];
  const insertBefore = existing.find(r => order.indexOf(r.dataset.plan) > rowIndex);
  if (insertBefore) {
    puOtherEl.insertBefore(row, insertBefore);
  } else {
    puOtherEl.appendChild(row);
  }
}

function getDefaultTabForSelected(row) {
  const tab = row.dataset.tab;
  const order = PLAN_ORDER[tab] || [];
  if (order.indexOf(row.dataset.plan) === 0) {
    return tab === 'individual' ? 'combo' : 'individual';
  }
  return tab;
}

function applyPlanFilter() {
  const selected = document.querySelector('.pu-plan-row.is-selected');
  if (!selected) return;
  const selectedTab = selected.dataset.tab;
  const selectedPlan = selected.dataset.plan;
  const order = PLAN_ORDER[selectedTab] || [];
  const selectedIdx = order.indexOf(selectedPlan);
  getAllRows().forEach(row => {
    if (row === selected) return;
    if (!puOtherEl.contains(row)) return; // committed plan card always visible
    const rowTab = row.dataset.tab;
    const rowPlan = row.dataset.plan;
    if (rowTab !== puActiveTab) {
      row.classList.add('hidden');
      return;
    }
    if (rowTab === selectedTab) {
      row.classList.toggle('hidden', order.indexOf(rowPlan) >= selectedIdx);
    } else {
      if (selectedTab === 'individual') {
        row.classList.remove('hidden');
      } else {
        row.classList.toggle('hidden', rowPlan !== 'premium');
      }
    }
  });
}

puPlansEl.addEventListener('click', (e) => {
  if (e.target.closest('.pu-plan-addon')) return;
  const row = e.target.closest('.pu-plan-row');
  if (!row) return;
  selectPlan(row);
});

puOtherEl.addEventListener('click', (e) => {
  if (e.target.closest('.pu-plan-addon')) return;
  const row = e.target.closest('.pu-plan-row');
  if (!row) return;
  selectPlan(row);
});

function selectPlan(row) {
  const prev = document.querySelector('.pu-plan-row.is-selected');
  if (prev === row) return;

  if (prev) {
    prev.classList.remove('is-selected');
    prev.querySelector('input[type="radio"]').checked = false;
  }

  row.classList.remove('hidden');
  row.classList.add('is-selected');
  row.querySelector('input[type="radio"]').checked = true;

  const duoCheck = row.querySelector('.pu-duo-check');
  if (duoCheck) {
    duoCheck.checked = !!duoState[row.dataset.plan + '_' + row.dataset.tab];
    syncDuoLabel(row);
  }

  if (puOtherEl.classList.contains('pu-collapsed')) {
    const currentTop = puPlansEl.querySelector('.pu-plan-row');
    if (currentTop && currentTop !== row) {
      insertRowInOrder(currentTop);
    }
    puPlansEl.insertBefore(row, document.getElementById('puHideToggle'));
  }

  updateSummary();
  const defaultTab = getDefaultTabForSelected(row);
  puActiveTab = defaultTab;
  const newBtn = puPlansEl.querySelector(`.pu-plan-toggle-btn[data-plan-tab="${defaultTab}"]`);
  puPlansEl.querySelectorAll('.pu-plan-toggle-btn').forEach(b => b.classList.toggle('is-active', b === newBtn));
  document.querySelectorAll('[data-includes-tab]').forEach(el => {
    el.classList.toggle('hidden', el.dataset.includesTab !== row.dataset.tab);
  });
  applyPlanFilter();
}

function toggleDuo(e, labelEl) {
  e.stopPropagation();
  const row = labelEl.closest('.pu-plan-row');
  const checkbox = labelEl.querySelector('.pu-duo-check');
  checkbox.checked = !checkbox.checked;
  duoState[row.dataset.plan + '_' + row.dataset.tab] = checkbox.checked;
  syncDuoLabel(row);
  const selectedRow = puPlansEl.querySelector('.pu-plan-row');
  if (selectedRow === row) updateSummary();
}

function syncDuoLabel(row) {
  const addonRow = row.querySelector('.pu-addon-row');
  if (!addonRow) return;
  addonRow.classList.toggle('is-checked', !!row.querySelector('.pu-duo-check').checked);
}

function updateSummary() {
  const selected = document.querySelector('.pu-plan-row.is-selected');
  if (!selected) return;
  const duoCheck = selected.querySelector('.pu-duo-check');
  const isDuo = duoCheck && duoCheck.checked && selected.dataset.duoName;
  const name = isDuo ? selected.dataset.duoName : selected.dataset.name;
  const price = parseInt(isDuo ? selected.dataset.duoPrice : selected.dataset.price, 10);
  const duration = selected.dataset.summaryDuration;
  document.getElementById('puSummaryName').textContent = name;
  document.getElementById('puSummaryPrice').textContent = '₹' + price.toLocaleString('en-IN');
  document.getElementById('puSummaryDuration').textContent = isDuo ? duration + ' | 2 users' : duration;
  document.getElementById('puTotalAmount').textContent = '₹' + price.toLocaleString('en-IN');
}

function toggleOtherPlans() {
  const isCollapsed = puOtherEl.classList.toggle('pu-collapsed');
  document.getElementById('puHideToggleLabel').textContent = isCollapsed ? 'Show other plans' : 'Hide other plans';
  document.getElementById('puHideChevron').classList.toggle('is-collapsed', isCollapsed);

  if (isCollapsed) {
    const selected = puOtherEl.querySelector('.pu-plan-row.is-selected');
    if (selected) {
      const currentTop = puPlansEl.querySelector('.pu-plan-row');
      if (currentTop && currentTop !== selected) {
        if (currentTop.dataset.tab !== selected.dataset.tab) {
          currentTop.classList.add('hidden');
        }
        insertRowInOrder(currentTop);
      }
      puPlansEl.insertBefore(selected, document.getElementById('puHideToggle'));
      if (selected.dataset.tab !== puActiveTab) {
        puActiveTab = selected.dataset.tab;
        const newBtn = puPlansEl.querySelector(`.pu-plan-toggle-btn[data-plan-tab="${puActiveTab}"]`);
        puPlansEl.querySelectorAll('.pu-plan-toggle-btn').forEach(b => b.classList.toggle('is-active', b === newBtn));
      }
      updateSummary();
    } else {
      const currentTop = puPlansEl.querySelector('.pu-plan-row');
      if (currentTop && !currentTop.classList.contains('is-selected')) {
        currentTop.classList.add('is-selected');
        const radio = currentTop.querySelector('input[type="radio"]');
        if (radio) radio.checked = true;
      }
    }
  }
}

function switchPlanTab(btn, tab, preselectPlan, isInit) {
  puPlansEl.querySelectorAll('.pu-plan-toggle-btn').forEach(b => b.classList.toggle('is-active', b === btn));

  if (isInit) {
    puActiveTab = tab;
    getAllRows().forEach(row => {
      row.classList.toggle('hidden', row.dataset.tab !== tab);
      if (row.dataset.tab !== tab) {
        row.classList.remove('is-selected');
        row.querySelector('input[type="radio"]').checked = false;
      }
    });

    const prev = puPlansEl.querySelector('.pu-plan-row');
    if (prev) insertRowInOrder(prev);

    const allRows = getAllRows().filter(r => r.dataset.tab === tab);
    const targetPlan = preselectPlan || getFirstPlanForTab(tab);
    const targetRow = allRows.find(r => r.dataset.plan === targetPlan) || allRows[0];
    targetRow.classList.remove('hidden');
    targetRow.classList.add('is-selected');
    targetRow.querySelector('input[type="radio"]').checked = true;
    puPlansEl.insertBefore(targetRow, document.getElementById('puHideToggle'));
    updateSummary();

    document.querySelectorAll('[data-includes-tab]').forEach(el => {
      el.classList.toggle('hidden', el.dataset.includesTab !== targetRow.dataset.tab);
    });
    puActiveTab = getDefaultTabForSelected(targetRow);
    const defaultBtn = puPlansEl.querySelector(`.pu-plan-toggle-btn[data-plan-tab="${puActiveTab}"]`);
    puPlansEl.querySelectorAll('.pu-plan-toggle-btn').forEach(b => b.classList.toggle('is-active', b === defaultBtn));
    applyPlanFilter();
  } else {
    puActiveTab = tab;
    document.querySelectorAll('[data-includes-tab]').forEach(el => {
      el.classList.toggle('hidden', el.dataset.includesTab !== tab);
    });
    applyPlanFilter();
  }
}

const PROMO_VALID_CODES = ['CIBIL100', 'SAVE10'];

function switchPromoTab(btn) {
  document.querySelectorAll('.pu-promo-tab').forEach(b => b.classList.toggle('is-active', b === btn));
  const type = btn.dataset.promoType;
  document.getElementById('puPromoLabel').textContent = type === 'discount' ? 'Enter Discount Code' : 'Enter Referral Code';
  const input = document.getElementById('puPromoInput');
  const msg   = document.getElementById('puPromoMsg');
  input.value = '';
  input.classList.remove('is-success', 'is-error');
  msg.classList.remove('is-visible', 'is-success', 'is-error');
}

function applyPromo() {
  const input = document.getElementById('puPromoInput');
  const msg   = document.getElementById('puPromoMsg');
  const code  = input.value.trim().toUpperCase();

  input.classList.remove('is-success', 'is-error');
  msg.classList.remove('is-visible', 'is-success', 'is-error');

  if (!code) {
    input.classList.add('is-error');
    msg.classList.add('is-visible', 'is-error');
    msg.textContent = 'Please enter a promo code.';
    return;
  }

  if (PROMO_VALID_CODES.includes(code)) {
    input.classList.add('is-success');
    msg.classList.add('is-visible', 'is-success');
    msg.textContent = 'Promo code applied successfully!';
  } else {
    input.classList.add('is-error');
    msg.classList.add('is-visible', 'is-error');
    msg.textContent = 'Invalid promo code. Please try again.';
  }
  input.blur();
}

(function initFromQueryString() {
  const params = new URLSearchParams(window.location.search);
  const tab = params.get('tab') === 'combo' ? 'combo' : 'individual';
  const plan = params.get('plan');
  const btn = document.querySelector(`.pu-plan-toggle-btn[data-plan-tab="${tab}"]`);
  // Start collapsed — no transition on load
  puOtherEl.style.transition = 'none';
  puOtherEl.classList.add('pu-collapsed');
  document.getElementById('puHideChevron').classList.add('is-collapsed');
  requestAnimationFrame(() => { puOtherEl.style.transition = ''; });
  switchPlanTab(btn, tab, plan, true);
})();
