/*
 * Privacy Notice popup only (same popup as free/paid consent.js, without the consent card).
 * API: PrivacyNotice.ready (Promise), .content(lang) -> {required, recommended, notice},
 *      .open(lang, alreadyRead, onDone), .loadFont() for Hindi.
 */
(function () {
  // Content lives in content/consent-en.txt and content/consent-hi.txt (see the notes at the top of those files).
  var CONTENT = { en: null, hi: null };

  function parseContent(text) {
    var out = { required: [], recommended: [], notice: [] }, section = null;
    text.split(/\r?\n/).forEach(function (raw) {
      var line = raw.trim();
      if (/^\s+- /.test(raw)) line = '  ' + line; // keep nested-bullet indent
      if (!line || line.indexOf('//') === 0) return;
      var m = line.match(/^\[(required|recommended|notice)\]$/i);
      if (m) { section = m[1].toLowerCase(); return; }
      if (section) out[section].push(line);
    });
    return out;
  }

  // Notice markup: "## " heading, "### " sub-heading, "- " bullet, "  - " nested bullet,
  // "| a | b |" table row (first row of a table = header), "== " closing line, else paragraph.
  function noticeHTML(lines) {
    var html = '', list = 0, table = false;
    function closeList(to) { while (list > to) { html += '</li></ul>'; list--; } }
    lines.forEach(function (line) {
      var depth = line.indexOf('  - ') === 0 ? 2 : line.indexOf('- ') === 0 ? 1 : 0;
      if (depth) {
        if (depth > list) { html += '<ul>'; list++; } else { closeList(depth); html += '</li>'; }
        html += '<li>' + line.slice(depth * 2);
        return;
      }
      closeList(0);
      if (line.indexOf('| ') === 0) {
        var cells = line.replace(/^\|\s*|\s*\|$/g, '').split(/\s*\|\s*/), tag = table ? 'td' : 'th';
        if (!table) { html += '<div class="cc-table"><table>'; table = true; }
        html += '<tr><' + tag + '>' + cells.join('</' + tag + '><' + tag + '>') + '</' + tag + '></tr>';
        return;
      }
      if (table) { html += '</table></div>'; table = false; }
      if (line.indexOf('### ') === 0) html += '<h4>' + line.slice(4) + '</h4>';
      else if (line.indexOf('## ') === 0) html += '<h3>' + line.slice(3) + '</h3>';
      else if (line.indexOf('== ') === 0 || line.indexOf('-- ') === 0) html += '<p class="cc-end">' + line.slice(3) + '</p>';
      else html += '<p>' + line + '</p>';
    });
    closeList(0);
    if (table) html += '</table></div>';
    return html;
  }

  function contentFor(lang) {
    var c = CONTENT[lang] || CONTENT.en;
    return {
      required: c.required.length ? c.required : CONTENT.en.required,
      recommended: c.recommended.length ? c.recommended : CONTENT.en.recommended,
      notice: c.notice.length ? c.notice : CONTENT.en.notice
    };
  }

  function load(lang) {
    return fetch('content/consent-' + lang + '.txt', { cache: 'no-cache' })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.text(); })
      .then(function (t) { CONTENT[lang] = parseContent(t); });
  }

  var modal, scrollArea, hint, doneBtn, onDone, fontLoaded;

  function loadDevanagariFont() {
    if (fontLoaded) return;
    fontLoaded = true;
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500&display=swap';
    document.head.appendChild(link);
  }

  function buildModal() {
    modal = document.createElement('dialog');
    modal.className = 'cc-modal';
    modal.setAttribute('aria-labelledby', 'ccModalTitle');
    modal.innerHTML =
      '<div class="cc-modal-head">' +
        '<img class="cc-modal-logo" src="./images/logo.svg" alt="CIBIL">' +
        '<h2 class="cc-modal-title" id="ccModalTitle">Privacy Notice</h2>' +
        '<button type="button" class="cc-modal-close" aria-label="Close">' +
          '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="#262626"/></svg>' +
        '</button>' +
      '</div>' +
      '<div class="cc-scroll" tabindex="0"></div>' +
      '<div class="cc-modal-foot">' +
        '<p class="cc-modal-hint" aria-live="polite">Scroll to the end of the notice to continue</p>' +
        '<button type="button" class="cc-done" disabled>Done</button>' +
      '</div>';
    document.body.appendChild(modal);
    scrollArea = modal.querySelector('.cc-scroll');
    hint = modal.querySelector('.cc-modal-hint');
    doneBtn = modal.querySelector('.cc-done');
    scrollArea.addEventListener('scroll', checkEnd);
    modal.querySelector('.cc-modal-close').addEventListener('click', function () { modal.close(); });
    doneBtn.addEventListener('click', function () {
      modal.close();
      if (onDone) onDone();
    });
  }

  function checkEnd() {
    if (scrollArea.scrollTop + scrollArea.clientHeight < scrollArea.scrollHeight - 4) return;
    doneBtn.disabled = false;
    hint.textContent = '✓ You’ve reached the end of the notice';
    hint.classList.add('is-done');
  }

  function openNotice(lang, alreadyRead, callback) {
    if (!modal) buildModal();
    scrollArea.innerHTML = '<p class="cc-scroll-title" lang="en" aria-hidden="true">Privacy Notice</p>' + noticeHTML(contentFor(lang).notice); // title repeated in scroll for mobile layout
    scrollArea.lang = (lang === 'hi' && CONTENT.hi && CONTENT.hi.notice.length) ? 'hi' : 'en';
    onDone = callback;
    doneBtn.disabled = !alreadyRead;
    hint.textContent = alreadyRead ? '✓ You’ve reached the end of the notice' : 'Scroll to the end of the notice to continue';
    hint.classList.toggle('is-done', alreadyRead);
    modal.showModal();
    scrollArea.scrollTop = 0;
    checkEnd(); // short screens: notice may already fit
  }

  window.PrivacyNotice = {
    ready: load('en').then(function () { return load('hi').catch(function () {}); }),
    content: contentFor,
    open: openNotice,
    loadFont: loadDevanagariFont
  };
})();
